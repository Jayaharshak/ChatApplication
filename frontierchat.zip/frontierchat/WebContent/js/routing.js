/**
 * 
 */

angular.module('login_module',['ui.router'])

	.config(function($stateProvider){
		$stateprovider
			.state('user',{
				templateUrl : 'chat_page.html'
			})
		
	})