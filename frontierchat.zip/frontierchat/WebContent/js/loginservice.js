angular.module('myApp')
	.service('loginService', ['$rootScope', '$state', '$http',function($rootScope,$state,$http){
		
		
		this.onLogin = function(mobilenumber,password){
		
			//GET request
			var url = "http://localhost:8080/frontierchat/rest/user/auth?mobilenumber="+mobilenumber+"&password="+password;

			console.log("##-----url--",url)
			$http({
			method: 'GET',
			url: url
			}).then(function successCallback(response) {

				var url="http://localhost:8080/frontierchat/rest/user/updatestatus?mobilenumber="+mobilenumber;
				$http({
				method: 'GET',
				url: url
					}).then(function successCallback(response) {
					console.log("user status updated",response);

					}, function errorCallback(response) {
					console.log("user status not updated",response);
					});

				var response = JSON.parse(response.data);
			if(response.Status == "Success"){
			// $scope.loginpagebool=false;
			// $scope.chatpagebool= true;
			$rootScope.username= response.username;
			$rootScope.mobilenumber = response.mobilenumber;
			$rootScope.id = response.id;
//			$scope.Online = response.isOnline;
			$state.go('chatpage.textchat');
//			$scope.connect();
//			$scope.getContactList();
	//setInterval(function(){$scope.getContactList(); }, 3000);
			}

			else {
			$rootScope.Status = 'Invalid user';

			}
			console.log(response);
			},

			function errorCallback(response) {
			$rootScope.Status = 'Invalid user';
			});
			//$scope.signinemail="";
			//$scope.signinpassword="";
		};
		
	}]);
	