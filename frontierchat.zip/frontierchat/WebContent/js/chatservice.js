
angular.module('myApp')
    .service('chatService', function($state, $http) {

        this.getContactList = function() {

            var url = "http://localhost:8080/frontierchat/rest/user/contactList";
            return $http({
                    method: 'GET',
                    url: url
                })
                .then(
                    function successCallback(
                        response) {

                        return response.data;

                    });
        }
        
        
        

    });