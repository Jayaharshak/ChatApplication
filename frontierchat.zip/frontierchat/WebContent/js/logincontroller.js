
angular.module('myApp')
.controller('loginController',['loginService','$scope', '$rootScope','$http','$state',
	function(loginService,$scope,$rootScope,$http,$state){


	$scope.yes = true;
	$scope.no = false;

	dateandtime = $scope.dateandtime;
	
	$scope.CurrentDate = new Date();

	/**
	 * For login authentication.
	 * 
	 * @param {string} mobilenumber - user mobilenumber.
	 * @param {string} password - user password.
	 */
	$scope.onLogin = function(mobilenumber,password) {

		loginService.onLogin(mobilenumber,password);
	
	};
	
	/**
	 * For new user signup with details.
	 * 
	 * @param {string} username - username for account.
	 * @param {string} mobilenumber - registering mobile number.
	 * @param {string} password - setting of password
	 * 
	 */
	$scope.onSignup = function(signupusername,signupmobilenumber,signuppassword) {

		var url = "http://localhost:8080/frontierchat/rest/user/add?username="+signupusername+"&mobilenumber="+signupmobilenumber+"&password="+signuppassword;

			console.log("##-----url--",url)
			$http({
			method: 'GET',
			url: url
			}).then(function successCallback(response) {
				/*var returnresponse = JSON.parse(response.data);*/
			if(response.status ==200){
			$scope.signupStatus ="Successfully registered";
			// $scope.loginpagebool = true;
			// $scope.chatpagebool = false;

			$state.go('home.loginform');


			$scope.signupusername = "";
			$scope.signupmobilenumber ="";
			$scope.signuppassword="";


			}
			else {
				$scope.signupStatus = "Registration failed !!";
				}

			},

			function errorCallback(response) {
				$scope.signupStatus = "Registration failed !!";
				});

		}
}]);
