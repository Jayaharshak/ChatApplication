angular.module('myApp', ["ui.router"]).config(
    function($stateProvider, $urlRouterProvider) {

        $urlRouterProvider.otherwise("/home/login");

        $stateProvider.state('home', {
            url: '/home',
            templateUrl: 'views/loginpage.html',
            controller: 'loginController'

        }).state('home.loginform', {
            url: '/login',
            templateUrl: 'views/loginform.html',
            controller: 'loginController'

        }).state('home.signupform', {
            url: '/signup',
            templateUrl: 'views/signupform.html'
        }).state('chatpage', {
            url: '/chatpage',
            templateUrl: 'views/chatpage.html',
            controller: 'mainController'

        }).state('chatpage.textchat', {
            url: '/textchat',
            templateUrl: 'views/textingpage.html'

        }).state('chatpage.audiopage', {
            url: '/audiopage',
            templateUrl: 'views/audiopage.html'

        }).state('chatpage.filesending', {
            url: '/filesending',
            templateUrl: 'views/filesending.html'

        }).state('chatpage.imagesending', {
            url: '/imagesending',
            templateUrl: 'views/imagesending.html'

        }).state('chatpage.scheduletext', {
            url: '/scheduletext',
            templateUrl: 'views/scheduletext.html'
        });
    });