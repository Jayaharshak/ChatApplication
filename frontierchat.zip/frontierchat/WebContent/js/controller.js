angular
		.module('myApp')

		.controller(
				"mainController",
				[
						'$scope',
						'$rootScope',
						'$http',
						'$timeout',
						'$state',
						function($scope, $rootScope, $http, $timeout, $state) {

							$scope.yes = true;
							$scope.no = false;
							$scope.textareadivbool = true;
							$scope.profiledivbool = false;

							dateandtime = $scope.dateandtime;
							/* $scope.$timeout = $timeout; */
							$scope.CurrentDate = new Date();

							$scope.getContactList = function() {

								var url = "http://localhost:8080/frontierchat/rest/user/contactList";
								$http({
									method : 'GET',
									url : url
								})
										.then(
												function successCallback(
														response) {
													
													$scope.details = response.data;

												},
												function errorCallback(response) {
													console.log(
															"-------err---",
															response);
												});
							}

							var ws;
							$scope.connect = function() {
								username = $scope.username;
								
								ws = new WebSocket(
										"ws://" + document.location.host + "/frontierchat/chat/"
												+ username);

								ws.onmessage = function(event) {
									var log = document
											.getElementById("chatlog");

									var message = JSON.parse(event.data);
									message.dateAndTime = $scope.CurrentDate;

									if (message.type == "image") {

										var span = document
												.createElement('div');
										span.innerHTML = [
												'<img class="thumb1" src="',
												message.content, '" title="',
												escape(message.type), '"/><br>' ]
												.join('');
										document.getElementById('log')
												.insertBefore(span, null);

									} else if (message.type == "audio") {

										var span = document
												.createElement('div');
										span.innerHTML = [
												'<audio  controls class="receiveaudioframe" src="',
												message.content, '" title="',
												message.type, '"/><br>' ]
												.join('');
										document.getElementById('log')
												.insertBefore(span, null);

									} else {
										var logdiv = document
												.getElementById('log');
										// Make a new div
										Child = document.createElement('span');
										Child2 = document.createElement("br");

										var attr = document
												.createAttribute("class"); // Create
																			// a
																			// "class"
																			// attribute
										attr.value = "appendedclass2";

										// Set the value of the class attribute
										Child.setAttributeNode(attr);
										// Give the new div some content
										Child.innerHTML = message.from + ":"
												+ message.content;

										// Jug it into the parent element
										logdiv.appendChild(Child);
										logdiv.appendChild(Child2);
									}

									

									// here http request to save chat log to
									// database.
									var url = "http://localhost:8080/frontierchat/rest/chat/savechatlog?fromuser="
											+ message.from
											+ "&touser="
											+ message.to
											+ "&chatcontent="
											+ message.content
											+ "&chattime="
											+ message.dateAndTime
											+ "&type="
											+ message.type;
									$http({
										method : 'GET',
										url : url
									})

								};

							}

							$scope.sendtext = function() {
								/* var log = document.getElementById("log"); */
								var content = document.getElementById("msg").value;
								/* var to = document.getElementById("to").value; */
								var to = $scope.displayname;
								
								var json = JSON.stringify({
									"to" : to,
									"content" : content,
									"type" : "text"
								
								});
								
								ws.send(json);

								// creating element to append this message.
								var logdiv = document.getElementById('log');
								// Make a new div
								Child = document.createElement('div');
								Child2 = document.createElement("br");

								var att = document.createAttribute("class"); // Create a class
																				
								att.value = "appendedclass";

								// Set the value of the class attribute
								Child.setAttributeNode(att);
								// Give the new div some content
								Child.innerHTML = content;

								// Jug it into the parent element
								logdiv.appendChild(Child);
								logdiv.appendChild(Child2);

								
								document.getElementById("msg").value = ""
							};

							

							$scope.scheduleMessage = function() {
								
								var time = document.getElementById('timedelay').value;
								

								var content = document
										.getElementById("schedule_msg").value;

								var to = $scope.displayname;

								var json = JSON.stringify({
									"to" : to,
									"content" : content,
									"type" : "text"

								});

								$timeout(ws.send(json), time);

								var logdiv = document.getElementById('log');

								Child = document.createElement('span');
								Child2 = document.createElement("br");

								var att = document.createAttribute("class"); // Create a class
																				
								att.value = "appendedclass glyphicons glyphicons-chat";

								
								Child.setAttributeNode(att);
								
								Child.innerHTML = "message :"
										+ content
										+ " ...will be sent after {{$scope.delaytime}} minutes.";

								
								logdiv.appendChild(Child);
								logdiv.appendChild(Child2);

								
								document.getElementById("schedule_msg").value = ""

							}

							$scope.sendimage = function() {

								var to = $scope.displayname;
								var content = $scope.imageurl;

								
								var json = JSON.stringify({
									"to" : to,
									"content" : content,
									"type" : "image"
								
								});
								
								ws.send(json);

								document.getElementById("files").value = "";
							};

							$scope.sendaudio = function() {

								var to = $scope.displayname;
								var content = $scope.audiourl;

								var json = JSON.stringify({
									"to" : to,
									"content" : content,
									"type" : "audio"
								
								});

								ws.send(json);
							}

							// On selecting a file function...

							$scope.handleFileSelect = function(event) {
								
								var files = event.target.files; // FileList
											
								for (var i = 0, f; f = files[i]; i++) {

									

									var reader = new FileReader();

									
									reader.onload = (function(theFile) {
										return function(e) {
											
											var span = document
													.createElement('div');
											span.innerHTML = [
													'<img class="thumb" src="',
													e.target.result,
													'" title="',
													escape(theFile.name), '"/>' ]
													.join('');
											document.getElementById('log')
													.insertBefore(span, null);
											$scope.imageurl = e.target.result;

										};
									})(f);

									// Read in the image file as a data URL.
									reader.readAsDataURL(f);
								}

								$scope.imagesendbuttonbool = true;
							}

							$scope.handleAudioSelect = function(event) {
								
								var files = event.target.files; // FileList
																// object

								// Loop through the FileList and render image
								// files as thumbnails.
								for (var i = 0, f; f = files[i]; i++) {

									// Only process image files.
									/*
									 * if (!f.type.match('image.*')) { continue; }
									 */

									var reader = new FileReader();

									// Closure to capture the file information.
									reader.onload = (function(theFile) {
										return function(e) {
											// Render thumbnail.
											var span = document
													.createElement('div');
											span.innerHTML = [
													'<audio controls class="sendaudioframe" src="',
													e.target.result,
													'" title="',
													escape(theFile.name), '"/>' ]
													.join('');
											document.getElementById('log')
													.insertBefore(span, null);
											$scope.audiourl = e.target.result;

										};
									})(f);

									// Read in the image file as a data URL.
									reader.readAsDataURL(f);
								}

							}

							$scope.onSelectingContact = function(user) {

								$scope.displayname = user.username;
								$scope.displayname_icon = true;
								$scope.messageheadbool = true;
								$scope.chatroomheadbool = false;
								/* displayname = $scope.displayname; */
								$('#log').text("");

								var url = "http://localhost:8080/frontierchat/rest/chat/getchatlog?fromuser="
										+ $rootScope.username
										+ "&touser="
										+ $scope.displayname;
								$http({
									method : 'GET',
									url : url
								})
										.then(
												function successCallback(
														response) {
													
													$scope.chatlogs = response.data;

													var loghistory = response.data;

													var i = 0;

													for (i = 0; i < loghistory.length; i++) {
														if ((loghistory[i].fromuser == $rootScope.username 
																	&& loghistory[i].touser == $scope.displayname)) {

															if (loghistory[i].type == "image") {

																var span = document
																		.createElement('div');
																span.innerHTML = [
																		'<img class=" appendedclass thumb" src="',
																		loghistory[i].chatcontent,
																		'" title="',
																		loghistory[i].type,
																		'"/>' ]
																		.join('');
																document
																		.getElementById(
																				'log')
																		.insertBefore(
																				span,
																				null);

															} else if (loghistory[i].type == "audio") {

																var span = document
																		.createElement('div');
																span.innerHTML = [
																		'<audio controls class=" appendedclass sendaudioframe" src="',
																		loghistory[i].chatcontent,
																		'" title="',
																		escape(theFile.name),
																		'"/>' ]
																		.join('');
																document
																		.getElementById(
																				'log')
																		.insertBefore(
																				span,
																				null);

															} else {
																var logdiv = document
																		.getElementById('log');
																Child = document
																		.createElement('span');
																Child2 = document
																		.createElement("br");

																var attr = document
																		.createAttribute("class");
																attr.value = "appendedclass glyphicons glyphicons-chat";

																Child
																		.setAttributeNode(attr);

																Child.innerHTML = loghistory[i].chatcontent;

																logdiv
																		.appendChild(Child);
																logdiv
																		.appendChild(Child2);

															}

															
														} else if ((loghistory[i].fromuser == $scope.displayname 
																	&& loghistory[i].touser == $rootScope.username)) {

															if (loghistory[i].type == "image") {

																var span = document
																		.createElement('div');
																span.innerHTML = [
																		'<img class=" appendedclass2 thumb" src="',
																		loghistory[i].chatcontent,
																		'" title="',
																		loghistory[i].type,
																		'"/>' ]
																		.join('');
																document
																		.getElementById(
																				'log')
																		.insertBefore(
																				span,
																				null);

															} else if (loghistory[i].type == "audio") {

																var span = document
																		.createElement('div');
																span.innerHTML = [
																		'<audio controls class=" appendedclass2 sendaudioframe" src="',
																		loghistory[i].chatcontent,
																		'" title="',
																		escape(theFile.name),
																		'"/>' ]
																		.join('');
																document
																		.getElementById(
																				'log')
																		.insertBefore(
																				span,
																				null);

															} else {

																var logdiv = document
																		.getElementById('log');
																Child = document
																		.createElement('span');
																Child2 = document
																		.createElement('br');

																var attr = document
																		.createAttribute("class");
																attr.value = "appendedclass2 ";

																Child
																		.setAttributeNode(attr);

																Child.innerHTML = loghistory[i].chatcontent;

																logdiv
																		.appendChild(Child);
																logdiv
																		.appendChild(Child2);
															}

														}

													}

												});

							}

							$scope.onSelectingGroupchat = function() {

								$('#log').text("Welcome to Chat room...!!");
								$scope.displayname = null;
								$scope.messageheadbool = false;
								$scope.chatroomheadbool = true;

							}

							
							$scope.showProfile = function() {

								$scope.profiledivbool = true;
								
								$scope.textareadivbool = false;
							};

							$scope.hideProfile = function() {

								$scope.profiledivbool = false;
								
								$scope.textareadivbool = true;

							};

						
							$scope.connect();
							$scope.getContactList();
							setInterval(function() {
								$scope.getContactList();
							}, 3000);

						} ]);
