angular.module('myApp')
    .controller("mainController", ['chatService',
        '$scope',
        '$rootScope',
        '$http',
        '$state',
        function(chatService, $scope, $rootScope, $http, $state) {
            //On loading page show text area and hide profile.
            $scope.yes = true;
            $scope.no = false;
            $scope.textareadivbool = true;
            $scope.profiledivbool = false;
            $scope.CurrentDate = new Date(); //Reading date4 and time
            //Function to get contact list.
            $scope.getContactList = function() {
                chatService.getContactList().then(function(details) {
                    $scope.details = details;
                })
            }

            /**
             * Connect function to start new websocket clients.
             * .
             * for websocket onmessage method called to receive  messages.
             */
            var ws;
            $scope.connect = function() {
                username = $scope.username;
                ws = new WebSocket(
                    "ws://" + document.location.host + "/frontierchat/chat/" +
                    username);
                ws.onmessage = function(event) {
                    var log = document.getElementById("chatlog");
                    var message = JSON.parse(event.data);
                    message.dateAndTime = $scope.CurrentDate;

                    if (message.type == "image") {
                        var span = document.createElement('div');
                        span.innerHTML = [
                            '<img class="thumb1" src="',
                            message.content, '" title="',
                            escape(message.type), '"/><br>'
                        ].join('');
                        document.getElementById('log')
                            .insertBefore(span, null);
                    } else if (message.type == "audio") {

                        var span = document.createElement('div');
                        span.innerHTML = [
                            '<audio  controls class="receiveaudioframe" src="',
                            message.content, '" title="',
                            message.type, '"/><br>'
                        ].join('');
                        document.getElementById('log')
                            .insertBefore(span, null);
                    } else {
                        var logdiv = document.getElementById('log');
                        // Make a new div
                        Child = document.createElement('span');
                        Child2 = document.createElement("br");

                        var attr = document.createAttribute("class");
                        attr.value = "appendedclass2";
                        // Set the value of the class attribute
                        Child.setAttributeNode(attr);
                        // Give the new div some content
                        Child.innerHTML = message.from + ":" +
                            message.content;
                        // Jug it into the parent element
                        logdiv.appendChild(Child2);
                        logdiv.appendChild(Child);
                        logdiv.appendChild(Child2);
                    }
                    // here http request to save chat log to database
                    var url = "http://localhost:8080/frontierchat/rest/chat/savechatlog?fromuser=" +
                        message.from +
                        "&touser=" +
                        message.to +
                        "&chatcontent=" +
                        message.content +
                        "&chattime=" +
                        message.dateAndTime +
                        "&type=" +
                        message.type;
                    $http({
                        method: 'GET',
                        url: url
                    })
                };
            }

            /**
             * send text function to send text message.
             * and also creates and append a div to chat area.
             * With chat content.
             *
             */
            $scope.sendtext = function(ws,displayname) {
               
                var content = document.getElementById("msg").value;
                /* var to = document.getElementById("to").value; */
                var to = displayname;
                var json = JSON.stringify({
                    "to": to,
                    "content": content,
                    "type": "text"
                });
                ws.send(json);

                // creating element to append this message.
                var logdiv = document.getElementById('log');
                // Make a new div
                Child = document.createElement('span');
                Child2 = document.createElement("br");
                var att = document.createAttribute("class"); // Create a class
                att.value = "appendedclass";
                // Set the value of the class attribute
                Child.setAttributeNode(att);
                // Give the new div some content
                Child.innerHTML = content;
                // Append child elements into the parent element
                logdiv.appendChild(Child2);
                logdiv.appendChild(Child);
                logdiv.appendChild(Child2);
                document.getElementById("msg").value = ""
            };

            /**
             * scheduleMessage function to schedule text message.
             * Sends after delay time is completed.
             * and also creates and append a div to chatarea.
             * With chat content.
             *
             */
            $scope.scheduleMessage = function() {

                var time = document.getElementById('timedelay').value;
                content = document.getElementById("schedule_msg").value;
                to = $scope.displayname;
                json = JSON.stringify({
                    "to": to,
                    "content": content,
                    "type": "text"
                });
                setTimeout(function() {
                    ws.send(json)
                }, time);
                /*$timeout(ws.send(json), time);*/

                var logdiv = document.getElementById('log');
                Child = document.createElement('span');
                Child2 = document.createElement("br");
                var att = document.createAttribute("class"); // Create a class
                att.value = "appendedclass";
                Child.setAttributeNode(att);
                Child.innerHTML = "message :" + content +
                    " ...will be sent after " + time + " milliseconds.";
                logdiv.appendChild(Child);
                logdiv.appendChild(Child2);
                document.getElementById("schedule_msg").value = ""

            }

            $scope.sendimage = function() {

                var to = $scope.displayname;
                var content = $scope.imageurl;
                var json = JSON.stringify({
                    "to": to,
                    "content": content,
                    "type": "image"
                });
                ws.send(json);
                document.getElementById("files").value = "";
            };

            $scope.sendaudio = function() {

                var to = $scope.displayname;
                var content = $scope.audiourl;

                var json = JSON.stringify({
                    "to": to,
                    "content": content,
                    "type": "audio"

                });
                ws.send(json);
                document.getElementById("audiofiles").value = "";
            }

            // On selecting a file function...
            $scope.handleFileSelect = function(event) {

                var files = event.target.files; // FileList
                for (var i = 0, f; f = files[i]; i++) {

                    var reader = new FileReader();
                    reader.onload = (function(theFile) {
                        return function(e) {
                            var div = document.createElement('div');
                            div.innerHTML = [
                                '<img class="thumb" src="',
                                e.target.result, '" title="',
                                escape(theFile.name), '"/>'
                            ].join('');
                            document.getElementById('log')
                                .insertBefore(div, null);
                            $scope.imageurl = e.target.result;
                        };
                    })(f);
                    // Read in the image file as a data URL.
                    reader.readAsDataURL(f);
                }

                $scope.imagesendbuttonbool = true;
            }

            $scope.handleAudioSelect = function(event) {

                var files = event.target.files; // FileList
                // object

                // Loop through the FileList and render image
                // files as thumbnails.
                for (var i = 0, f; f = files[i]; i++) {

                    var reader = new FileReader();
                    reader.onload = (function(theFile) {
                        return function(e) {
                            // Render thumbnail.
                            var div = document.createElement('div');
                            div.innerHTML = [
                                '<audio controls class="sendaudioframe" src="',
                                e.target.result, '" title="',
                                escape(theFile.name), '"/>'
                            ].join('');
                            document.getElementById('log')
                                .insertBefore(div, null);
                            $scope.audiourl = e.target.result;
                        };
                    })(f);

                    // Read in the image file as a data URL.
                    reader.readAsDataURL(f);
                }

            }

            $scope.onSelectingContact = function(user) {

                $scope.displayname = user.username;
                $scope.displayname_icon = true;
                $scope.messageheadbool = true;
                $scope.chatroomheadbool = false;
                /* displayname = $scope.displayname; */
                $('#log').text("");

                var url =
                    "http://localhost:8080/frontierchat/rest/chat/getchatlog?fromuser=" +
                    $rootScope.username +
                    "&touser=" +
                    $scope.displayname;
                $http({
                    method: 'GET',
                    url: url
                }).then(
                    function successCallback(response) {

                        $scope.chatlogs = response.data;
                        var loghistory = response.data;
                        for (var i = 0; i < loghistory.length; i++) {
                            if ((loghistory[i].fromuser == $rootScope.username &&
                                    loghistory[i].touser == $scope.displayname)) {

                                if (loghistory[i].type == "image") {

                                    var div = document
                                        .createElement('div');
                                    div.innerHTML = [
                                        '<img class=" appendedclass thumb" src="',
                                        loghistory[i].chatcontent,
                                        '" title="',
                                        loghistory[i].type,
                                        '"/>'
                                    ].join('');
                                    document.getElementById('log')
                                        .insertBefore(div, null);

                                } else if (loghistory[i].type == "audio") {

                                    var div = document
                                        .createElement('div');
                                    div.innerHTML = [
                                        '<audio controls class=" appendedclass sendaudioframe" src="',
                                        loghistory[i].chatcontent,
                                        '" title="',
                                        escape(theFile.name),
                                        '"/>'
                                    ].join('');
                                    document.getElementById('log')
                                        .insertBefore(div, null);

                                } else {
                                    var logdiv = document
                                        .getElementById('log');
                                    Child = document
                                        .createElement('span');
                                    Child2 = document
                                        .createElement("br");

                                    var attr = document
                                        .createAttribute("class");
                                    attr.value = "appendedclass";
                                    Child.setAttributeNode(attr);
                                    Child.innerHTML = loghistory[i].chatcontent;
                                    logdiv.appendChild(Child);
                                    logdiv.appendChild(Child2);

                                }

                            } else if ((loghistory[i].fromuser == $scope.displayname &&
                                    loghistory[i].touser == $rootScope.username)) {

                                if (loghistory[i].type == "image") {

                                    var div = document
                                        .createElement('div');
                                    div.innerHTML = [
                                        '<img class=" appendedclass2 thumb" src="',
                                        loghistory[i].chatcontent,
                                        '" title="',
                                        loghistory[i].type,
                                        '"/><br>'
                                    ].join('');
                                    document.getElementById('log')
                                        .insertBefore(div, null);

                                } else if (loghistory[i].type == "audio") {

                                    var div = document
                                        .createElement('div');
                                    div.innerHTML = [
                                        '<audio controls class=" appendedclass2 sendaudioframe" src="',
                                        loghistory[i].chatcontent,
                                        '" title="',
                                        escape(theFile.name),
                                        '"/><br>'
                                    ].join('');
                                    document.getElementById('log')
                                        .insertBefore(div, null);

                                } else {

                                    var logdiv = document
                                        .getElementById('log');
                                    Child = document
                                        .createElement('span');
                                    Child2 = document
                                        .createElement('br');

                                    var attr = document
                                        .createAttribute("class");
                                    attr.value = "appendedclass2 ";
                                    Child.setAttributeNode(attr);
                                    Child.innerHTML = loghistory[i].chatcontent;
                                    logdiv.appendChild(Child);
                                    logdiv.appendChild(Child2);
                                }

                            }

                        }

                    });

            }

            $scope.onSelectingGroupchat = function() {

                $('#log').text("Welcome to Chat room...!!");
                $scope.displayname = null;
                $scope.messageheadbool = false;
                $scope.chatroomheadbool = true;

            }


            $scope.showProfile = function() {

                $scope.profiledivbool = true;
                $scope.textareadivbool = false;
            };

            $scope.hideProfile = function() {

                $scope.profiledivbool = false;
                $scope.textareadivbool = true;

            };


            $scope.connect();
            $scope.getContactList();
            $scope.onSelectingGroupchat();
            setInterval(function() {
                $scope.getContactList();
            }, 3000);

        }
    ]);
