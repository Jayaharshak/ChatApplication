var app = angular.module('myApp', []);

app.controller("logincontroller",['$scope', '$rootScope','$http','$timeout',function($scope,$rootScope,$http,$timeout){
	$scope.loginpagebool = true;
	$scope.chatpagebool =false;
	$scope.messageheadbool = false;
	$scope.chatroomheadbool = true;
	$scope.textingdivbool = true;
	$scope.filesendingdivbool = false;

	$scope.profiledivbool = false;
	$scope.historydivbool = true;
	$scope.textareadivbool = true

	$scope.yes = true;
	$scope.no = false;
	$scope.displayname_icon = false;
	dateandtime = $scope.dateandtime;
	$scope.imagesendbuttonbool = false;
	
	$scope.schedule_writebool = false;
	$scope.image_writebool = false;
	$scope.textingdivbool = true;
	$scope.audio_writebool = false;
	$scope.file_writebool = false;
	
	$scope.$timeout = $timeout;
	  /*document.getElementById('files').addEventListener('change', $scope.handleFileSelect);*/
	  
	  
	/*instance of date to daiplay time and date.*/
	$scope.CurrentDate = new Date();

/*	
	$scope.showtextingdiv = function() {
		
		$scope.schedule_writebool = false;
		$scope.image_writebool = false;
		$scope.textingdivbool = true;
		$scope.audio_writebool = false;
		$scope.file_writebool = false;
		
	};*/
	
	

	$scope.getContactList = function() {

		var url="http://localhost:8080/frontierchat/rest/user/contactList";
		$http({
		method: 'GET',
		url: url
			}).then(function successCallback(response) {
			console.log("-----success response is-----",response);
			$scope.details = response.data;
		
			}, function errorCallback(response) {
			console.log("-------err---",response);
			});
	}

	$scope.onLogin=function(mobilenumber,password)	{


		//GET request
		var url = "http://localhost:8080/frontierchat/rest/user/auth?mobilenumber="+mobilenumber+"&password="+password;

		console.log("##-----url--",url)
		$http({
		method: 'GET',
		url: url
		}).then(function successCallback(response) {

			var url="http://localhost:8080/frontierchat/rest/user/updatestatus?mobilenumber="+mobilenumber;
			$http({
			method: 'GET',
			url: url
				}).then(function successCallback(response) {
				console.log("user status updated",response);

				}, function errorCallback(response) {
				console.log("user status not updated",response);
				});

			var response = JSON.parse(response.data);
		if(response.Status == "Success"){
		$scope.loginpagebool=false;
		$scope.chatpagebool= true;
		$rootScope.username= response.username;
		$scope.mobilenumber = response.mobilenumber;
		$scope.id = response.id;
		$scope.Online = response.isOnline;
		$scope.connect();
		$scope.getContactList();
		setInterval(function(){$scope.getContactList(); }, 3000);
		}

		else {
		$scope.Status = 'Invalid user';

		}
		console.log(response);
		},

		function errorCallback(response) {
		$scope.Status = 'Invalid user';
		});
		//$scope.signinemail="";
		//$scope.signinpassword="";

	}

	$scope.onSignup = function(signupusername,signupmobilenumber,signuppassword) {

		var url = "http://localhost:8080/frontierchat/rest/user/add?username="+signupusername+"&mobilenumber="+signupmobilenumber+"&password="+signuppassword;

			console.log("##-----url--",url)
			$http({
			method: 'GET',
			url: url
			}).then(function successCallback(response) {
				/*var returnresponse = JSON.parse(response.data);*/
			if(response.status ==200){
			$scope.signupStatus ="Successfully registered";
			$scope.loginpagebool = true;
			$scope.chatpagebool = false;


			$scope.signupusername = "";
			$scope.signupmobilenumber ="";
			$scope.signuppassword="";


			}
			else {
				$scope.signupStatus = "Registration failed !!";
				}

			},

			function errorCallback(response) {
				$scope.signupStatus = "Registration failed !!";
				});

		}


	var ws;
	$scope.connect = function(){
		username = $scope.username;
		/*var connectionName = user.Empname;*/
		/*var username = document.getElementById("username").value;*/
		ws = new WebSocket("ws://" + document.location.host + "/frontierchat/chat/" + username);

		ws.onmessage = function(event) {
		    var log = document.getElementById("chatlog");


		    	/*event.time = document.getElementById("dateandtime").value;*/
		        console.log("this is event.data"+event.data);
		        var message = JSON.parse(event.data);
		        message.dateAndTime = $scope.CurrentDate;
		        /*$scope.displaytime = getElementById('dateandtime').value;*/
		        /*console("this is displaying time"+displaytime);*/
		        console.log(message);
		        console.log("touser:"+message.to);
		        console.log("fromuser:"+message.from);
		        console.log("chatcontent:"+message.content);
		        console.log("chattime:"+message.dateAndTime);
		        console.log("type : "+message.type);
		        if(message.type=="image") {
		        	
		        	var span = document.createElement('span');
			          span.innerHTML = ['<img class="thumb1" src="', message.content,
			                            '" title="', escape(message.type), '"/>'].join('');
			          document.getElementById('log').insertBefore(span, null);
		        	
		        } else if(message.type=="audio"){
					
					var span = document.createElement('span');
			          span.innerHTML = ['<audio  controls class="receiveaudioframe" src="', message.content,
			                            '" title="', escape(message.type), '"/>'].join('');
			          document.getElementById('log').insertBefore(span, null);
					
					} else {
							var logdiv = document.getElementById('log');
							// Make a new div
							Child = document.createElement('span');
								Child2 = document.createElement("br");

							var attr = document.createAttribute("class");       // Create a "class" attribute
							attr.value = "appendedclass2 glyphicons glyphicons-chat";

							 // Set the value of the class attribute
							Child.setAttributeNode(attr);
							// Give the new div some content
							Child.innerHTML = message.from+":"+message.content;

							// Jug it into the parent element
							logdiv.appendChild(Child);
							logdiv.appendChild(Child2);
						}
		        
		       /* log.innerHTML += message.from + " : " + message.content + "\n";*/
			   /* }*/

		        // here http request to save chat log to database.
		        var url = "http://localhost:8080/frontierchat/rest/chat/savechatlog?fromuser="+message.from+"&touser="+message.to+"&chatcontent="+message.content+"&chattime="+message.dateAndTime;
		        $http({
					method: 'GET',
					url: url
					})


		    };

	}

	$scope.send = function() {
		/*var log = document.getElementById("log");*/
		var content = document.getElementById("msg").value;
	    /*var to = document.getElementById("to").value;*/
	    var to = $scope.displayname;
	    /*var time = document.getElementById("dateandtime").value;*/
	    var json = JSON.stringify({
	        "to":to,
	        "content":content,
	        "type":"text"
	        /*"time":time*/
	    });
	    /*$("#log").append("<p style='color:red' class='pull-right'>"+ content +"</p>");*/
	    console.log("our data" + json);
	    ws.send(json);

	    //creating element to append this message.
	    var logdiv = document.getElementById('log');
	    // Make a new div
	    Child = document.createElement('span');
			Child2 = document.createElement("br");

	    var att = document.createAttribute("class");       // Create a "class" attribute
	    att.value = "appendedclass glyphicons glyphicons-chat";

	     // Set the value of the class attribute
	    Child.setAttributeNode(att);
	// Give the new div some content
	Child.innerHTML = content;

	// Jug it into the parent element
	logdiv.appendChild(Child);
	logdiv.appendChild(Child2);


	    /*log.innerHTML += "Me : " + content + "\n";*/
	    document.getElementById("msg").value = ""
	};

	
	 // must be injected in controller.
	 
	 $scope.scheduleMessage = function() {
		 /*$rootSscope.delaytime = $scope.delaytime;*/
		 $scope.time = eval($scope.delaytime * 60000);
		 
		 var content = document.getElementById("schedule_msg").value;
		    
		    var to = $scope.displayname;
		    
		    var json = JSON.stringify({
		        "to":to,
		        "content":content,
		        "type":"text"
		        
		    });
		 
	$timeout(ws.send(json),$scope.time);
	
	var logdiv = document.getElementById('log');
    
    Child = document.createElement('span');
		Child2 = document.createElement("br");

    var att = document.createAttribute("class");       // Create a "class" attribute
    att.value = "appendedclass glyphicons glyphicons-chat";

     // Set the value of the class attribute
    Child.setAttributeNode(att);
// Give the new div some content
Child.innerHTML = "message :"+content+" ...will be sent after {{$scope.delaytime}} minutes.";

// Jug it into the parent element
logdiv.appendChild(Child);
logdiv.appendChild(Child2);


    /*log.innerHTML += "Me : " + content + "\n";*/
    document.getElementById("schedule_msg").value = ""
	
	 }

	$scope.sendimage = function() {
		

			
	    var to = $scope.displayname;
	    var content = $scope.imageurl;
	    
	    /*var img = document.getElementById("filediv");*/
	    /*var time = document.getElementById("dateandtime").value;*/
	    var json = JSON.stringify({
	        "to":to,
	        "content":content,
	        "type":"image"
	        /*"time":time*/
	    });
	    /*$("#log").append("<p style='color:red' class='pull-right'>"+ content +"</p>");*/
	    console.log("our data for image" + json);
	    ws.send(json);

	    document.getElementById("files").value = "";
	};
	
	$scope.sendaudio = function () {
		
		var to = $scope.displayname;
	    var content = $scope.imageurl;
		
		/*var span = document.createElement('span');
	          span.innerHTML = ['<audio class="sendaudioframe" src="',  $scope.audiourl,
	                            '" title="', escape(theFile.name), '"/>'].join('');
	          document.getElementById('log').insertBefore(span, null);*/
			  
		var json = JSON.stringify({
	        "to":to,
	        "content":content,
	        "type":"audio"
	        /*"time":time*/
	    });
		
		ws.send(json);
	}
	
	// On selecting a file function...
	
	$scope.handleFileSelect = function(event) {
		console.log("triggering event listener functionality");
	    var files = event.target.files; // FileList object

	    // Loop through the FileList and render image files as thumbnails.
	    for (var i = 0, f; f = files[i]; i++) {

	      // Only process image files.
	      /*if (!f.type.match('image.*')) {
	        continue;
	      }*/

	      var reader = new FileReader();

	      // Closure to capture the file information.
	      reader.onload = (function(theFile) {
	        return function(e) {
	          // Render thumbnail.
	          var span = document.createElement('span');
	          span.innerHTML = ['<img class="thumb" src="', e.target.result,
	                            '" title="', escape(theFile.name), '"/>'].join('');
	          document.getElementById('log').insertBefore(span, null);
			  $scope.imageurl = e.target.result;
			  
			  console.log("imageurl is here "+$scope.imageurl);
	        };
	      })(f);

	      // Read in the image file as a data URL.
	      reader.readAsDataURL(f);
	    }
	    
	    $scope.imagesendbuttonbool = true;
	  }

	
	$scope.handleAudioSelect = function(event) {
		console.log("triggering audio event listener functionality");
	    var files = event.target.files; // FileList object

	    // Loop through the FileList and render image files as thumbnails.
	    for (var i = 0, f; f = files[i]; i++) {

	      // Only process image files.
	      /*if (!f.type.match('image.*')) {
	        continue;
	      }*/

	      var reader = new FileReader();

	      // Closure to capture the file information.
	      reader.onload = (function(theFile) {
	        return function(e) {
	          // Render thumbnail.
	           var span = document.createElement('span');
	          span.innerHTML = ['<audio controls class="sendaudioframe" src="', e.target.result,
	                            '" title="', escape(theFile.name), '"/>'].join('');
	          document.getElementById('log').insertBefore(span, null); 
			  $scope.audiourl = e.target.result;
			 
			  
	        };
	      })(f);

	      // Read in the image file as a data URL.
	      reader.readAsDataURL(f);
	    }
	    
	    
	  }

	  
	  

	
	 $scope.onSelectingContact = function(user) {

			$rootScope.displayname = user.username ;
			$scope.displayname_icon = true;
			$scope.messageheadbool = true;
			$scope.chatroomheadbool = false;
			displayname = $scope.displayname;
			 $('#log').text("");


			var url = "http://localhost:8080/frontierchat/rest/chat/getchatlog?fromuser="+$rootScope.username+"&touser ="+$rootScope.displayname;
			$http({
				method: 'GET',
				url: url
					}).then(function successCallback(response) {
					console.log("-----here is on selecting contact list respo-"+response);
					$scope.chatlogs = response.data;

					var loghistory = response.data;
					console.log(response.data);
					console.log("length of chatlogs"+loghistory.length);
					console.log("first element of chatlogs"+loghistory[0].fromuser);

					for(i=0;i<loghistory.length;i++) {
						if((loghistory[i].fromuser == $rootScope.username && loghistory[i].touser == $rootScope.displayname)){


				            var logdiv = document.getElementById('log');
						    Child = document.createElement('span');
								Child2 = document.createElement("br");

						    var attr = document.createAttribute("class");
						    attr.value = "appendedclass glyphicons glyphicons-chat";


						    Child.setAttributeNode(attr);

						    Child.innerHTML = loghistory[i].chatcontent;

						    logdiv.appendChild(Child);
								logdiv.appendChild(Child2);

				            /*console.log("refined logs"+chatlogs);*/
				        } else if ( (loghistory[i].fromuser == $rootScope.displayname && loghistory[i].touser == $rootScope.username)) {



				            var logdiv = document.getElementById('log');
						    Child = document.createElement('span');
								Child2 = document.createElement('br');

						    var attr = document.createAttribute("class");
						    attr.value = "appendedclass2 glyphicons glyphicons-chat";


						    Child.setAttributeNode(attr);

						    Child.innerHTML = loghistory[i].chatcontent;

						    logdiv.appendChild(Child);
								logdiv.appendChild(Child2);


				        }

					}


			});

			

	 }


	$scope.onSelectingGroupchat = function() {

		$('#log').text("Welcome to Chat room...!!");
		$scope.messageheadbool = false;
		$scope.chatroomheadbool = true;
	}

	/* $scope.showfilesendingdiv = function() {

		$scope.textingdivbool = false;
		$scope.filesendingdivbool = true;
	} */

	 

	$scope.showProfile = function() {

		$scope.profiledivbool = true;
		$scope.historydivbool = false;
		$scope.textareadivbool = false;
	};

	$scope.hideProfile = function() {

		$scope.profiledivbool = false;
		$scope.historydivbool = true;
		$scope.textareadivbool = true;

	};
	
	$scope.show_schedule_write = function() {
		
		$scope.schedule_writebool = true;
		$scope.image_writebool = false;
		$scope.textingdivbool = false;
		$scope.audio_writebool = false;
		$scope.file_writebool = false;
		
	};
	
	$scope.show_image_write = function() {
		
		$scope.schedule_writebool = false;
		$scope.image_writebool = true;
		$scope.textingdivbool = false;
		$scope.audio_writebool = false;
		$scope.file_writebool = false;
		
	};
	
	$scope.show_audio_write = function() {
		
		$scope.schedule_writebool = false;
		$scope.image_writebool = false;
		$scope.textingdivbool = false;
		$scope.audio_writebool = true;
		$scope.file_writebool = false;
		
	};
	
	$scope.show_file_write = function() {
		
		$scope.schedule_writebool = false;
		$scope.image_writebool = false;
		$scope.textingdivbool = false;
		$scope.audio_writebool = false;
		$scope.file_writebool = true;
		
	};
	
	$scope.showtextingdiv = function() {

		$scope.schedule_writebool = false;
		$scope.image_writebool = false;
		$scope.textingdivbool = true;
		$scope.audio_writebool = false;
		$scope.file_writebool = false;

	}

	
	
}]);


