/*
* class :ChatEndpoint 
* 
* Purpose: Websocket chat end point to Setup server for websocket.
* 
* Server side scripting for websocket.
*
*/

package com.ofs.frontierchat.websocket;

import java.io.IOException;
import java.util.HashMap;
import java.util.Set;
import java.util.concurrent.CopyOnWriteArraySet;
import java.util.logging.Logger;

import javax.websocket.EncodeException;
import javax.websocket.OnClose;
import javax.websocket.OnError;
import javax.websocket.OnMessage;
import javax.websocket.OnOpen;
import javax.websocket.Session;
import javax.websocket.server.PathParam;
import javax.websocket.server.ServerEndpoint;

import com.ofs.frontierchat.encryption.MessageDecoder;
import com.ofs.frontierchat.encryption.MessageEncoder;
import com.ofs.frontierchat.model.Message;
import com.ofs.frontierchat.service.UserService;
import com.ofs.frontierchat.service.UserServiceImpl;

/**
 * Frontierchat project
 * 
 * package com.ofs.frontierchat.websocket
 * 
 * ChatEndpoint.java
 * 
 * Purpose: created socket with given username.
 *
 * @author Jayaharsha
 *
 */
@ServerEndpoint(value = "/chat/{username}", decoders = MessageDecoder.class, encoders = MessageEncoder.class)
public class ChatEndpoint {
	private final Logger log = Logger.getLogger(getClass().getName());

	private Session session;
	private String username;
	private static final Set<ChatEndpoint> chatEndpoints = new CopyOnWriteArraySet<>();
	private static HashMap<String, String> users = new HashMap<>();

	@OnOpen
	public void onOpen(Session session, @PathParam("username") String username) throws IOException, EncodeException {
		log.info(session.getId() + " Is Online!");

		this.session = session;
		this.username = username;
		chatEndpoints.add(this);
		users.put(session.getId(), username);

		Message message = new Message();
		message.setFrom(username);
		message.setContent("connected!");
		broadcast(message);
	}

	@OnMessage
	public void onMessage(Session session, Message message) throws IOException, EncodeException {
		log.info(message.toString());
		log.info("here is onMessage string" + message.getType());
		if (getSessionId(message.getTo()) == null) {

			message.setFrom(users.get(session.getId()));
			broadcast(message);
			/* sendMessageToOneUser(message); */
		} else {

			message.setFrom(users.get(session.getId()));
			sendMessageToOneUser(message);
		}
	}

	@OnClose
	public void onClose(Session session) throws IOException, EncodeException {

		UserService userService = new UserServiceImpl();

		log.info(session.getId() + " disconnected!");

		chatEndpoints.remove(this);
		Message message = new Message();
		message.setFrom(users.get(session.getId()));
		message.setContent("disconnected!");
		userService.statusOffline(users.get(session.getId()));
		broadcast(message);

	}

	@OnError
	public void onError(Session session, Throwable throwable) {
		log.warning(throwable.toString());
	}

	private static void broadcast(Message message) throws IOException, EncodeException {
		for (ChatEndpoint endpoint : chatEndpoints) {
			synchronized (endpoint) {
				endpoint.session.getBasicRemote().sendObject(message);
			}
		}
	}

	private static void sendMessageToOneUser(Message message) throws IOException, EncodeException {
		for (ChatEndpoint endpoint : chatEndpoints) {
			synchronized (endpoint) {
				if (endpoint.session.getId().equals(getSessionId(message.getTo()))) {
					endpoint.session.getBasicRemote().sendObject(message);
				}
			}
		}
	}

	private static String getSessionId(String to) {
		if (users.containsValue(to)) {
			for (String sessionId : users.keySet()) {
				if (users.get(sessionId).equals(to)) {
					return sessionId;
				}
			}
		}
		return null;
	}
}