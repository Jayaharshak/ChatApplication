/*
* interface :UserService
* 
* Purpose: Service for user authentication and user table functionality.
*/
package com.ofs.frontierchat.service;

import java.util.List;

import com.ofs.frontierchat.model.User;

/**
 * Frontierchat project
 * 
 * package com.ofs.frontierchat.service
 * 
 * UserService.java
 * 
 * Purpose: interface with methods to save and retrieveuser details and
 * authentication.
 *
 * @author Jayaharsha
 *
 */
public interface UserService {

	public User findUserByMobilenumber(String mobilenumber, String password);

	public String addUser(User user);

	public List<User> getContactList();

	public String updateOnline(String mobilenumber);

	public String statusOffline(String username);

}
