package com.ofs.frontierchat.service;

import java.util.List;

import com.ofs.frontierchat.model.chatLog;

public interface ChatService {

	public String saveChatLog(chatLog newlog);

	public List<chatLog> getChatLogByUsername(String fromuser, String touser);

}
