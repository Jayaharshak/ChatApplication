/*
* interface :ChatService
* 
* Purpose: Service for saving chat log and getting chat history.
*/
package com.ofs.frontierchat.service;

import java.util.List;

import com.ofs.frontierchat.model.ChatLog;

/**
 * Frontierchat project
 * 
 * package com.ofs.frontierchat.service
 * 
 * ChatService.java
 * 
 * Purpose: interface with methods to save and retrieve chat history.
 *
 * @author Jayaharsha
 *
 */
public interface ChatService {

	public String saveChatLog(ChatLog newlog);

	public List<ChatLog> getChatLogByUsername(String fromuser, String touser);

}
