/*
* class :ChatServiceImpl 
* 
* Purpose: ChatServiceImpl implements ChatService interface
*
*/
package com.ofs.frontierchat.service;

import java.util.List;

import com.ofs.frontierchat.dao.ChatDao;
import com.ofs.frontierchat.dao.ChatDaoImpl;
import com.ofs.frontierchat.model.ChatLog;

/**
 * Frontierchat project
 * 
 * package com.ofs.frontierchat.service
 * 
 * ChatServiceImpl.java
 * 
 * Purpose: It implements the ChatService interface.
 *
 * @author Jayaharsha
 *
 */
public class ChatServiceImpl implements ChatService {

	ChatDao chatDao = new ChatDaoImpl();

	@Override
	public List<ChatLog> getChatLogByUsername(String fromuser, String touser) {

		return chatDao.getChatLogByUsername(fromuser, touser);
	}

	public String saveChatLog(ChatLog newlog) {

		return chatDao.saveChatLog(newlog);
	}
}
