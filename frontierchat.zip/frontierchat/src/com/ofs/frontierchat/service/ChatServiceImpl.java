package com.ofs.frontierchat.service;

import java.util.List;

import com.ofs.frontierchat.dao.ChatDao;
import com.ofs.frontierchat.dao.ChatDaoImpl;
import com.ofs.frontierchat.model.chatLog;

public class ChatServiceImpl implements ChatService {

	ChatDao chatDao = new ChatDaoImpl();

	@Override
	public List<chatLog> getChatLogByUsername(String fromuser, String touser) {

		return chatDao.getChatLogByUsername(fromuser, touser);
	}

	public String saveChatLog(chatLog newlog) {

		return chatDao.saveChatLog(newlog);
	}
}
