/*
* class :UserServiceImpl 
* 
* Purpose: UserServiceImpl implements UserService interface
*
*/
package com.ofs.frontierchat.service;

import java.util.List;

import com.ofs.frontierchat.dao.UserDao;
import com.ofs.frontierchat.dao.UserDaoImpl;
import com.ofs.frontierchat.model.User;

/**
 * Frontierchat project
 * 
 * package com.ofs.frontierchat.service
 * 
 * UserServiceImpl.java
 * 
 * Purpose: It implements the UserService interface.
 *
 * @author Jayaharsha
 *
 */
public class UserServiceImpl implements UserService {

	UserDao userDao = new UserDaoImpl();

	@Override
	public User findUserByMobilenumber(String mobilenumber, String password) {

		return userDao.findUserByMobilenumber(mobilenumber, password);
	}

	@Override
	public String addUser(User user) {

		return userDao.addUser(user);
	}

	@Override
	public List<User> getContactList() {

		return userDao.getContactList();
	}

	@Override
	public String updateOnline(String mobilenumber) {

		return userDao.updateOnline(mobilenumber);
	}

	@Override
	public String statusOffline(String username) {

		return userDao.statusOffline(username);
	}

}
