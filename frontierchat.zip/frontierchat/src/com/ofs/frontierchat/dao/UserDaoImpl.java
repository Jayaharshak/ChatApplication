package com.ofs.frontierchat.dao;

import java.util.List;

import com.ofs.frontierchat.model.User;
import com.ofs.frontierchat.util.HibernateUtil;

/**
 * Frontierchat project UserDaoImpl.java Purpose: It implements the UserDao
 * interface.
 *
 * @author Jayaharsha
 *
 */
public class UserDaoImpl implements UserDao {

	HibernateUtil hibernateUtil = new HibernateUtil();

	@Override
	/**
	 * fetch the data from user_table with given mobilenumber and password.
	 * 
	 * @param mobilenumber
	 * @param password
	 * @return user record.
	 */
	public User findUserByMobilenumber(String mobilenumber, String password) {
		hibernateUtil.openCurrentSession();

		User user = (User) hibernateUtil.getCurrentSession()
				.createQuery("from User where mobilenumber='" + mobilenumber + "' and password ='" + password + "'")
				.uniqueResult();

		hibernateUtil.closeCurrentSession();

		return user;
	}

	@Override

	/**
	 * Adding new user details to database on signup.
	 * 
	 * @param user
	 * @return String saying record of particular id saved successfully.
	 */
	public String addUser(User user) {

		hibernateUtil.openCurrentSessionwithTransaction();

		Integer id = (Integer) hibernateUtil.getCurrentSession().save(user);

		hibernateUtil.closeCurrentSessionwithTransaction();

		return "User record saved successfully with id:" + id;
	}

	@Override
	/**
	 * Returns total contacts list from user_table. Returns list.
	 */
	public List<User> getContactList() {

		hibernateUtil.openCurrentSession();

		List<User> contact_list = hibernateUtil.getCurrentSession().createQuery("from User").list();

		hibernateUtil.closeCurrentSession();

		return contact_list;
	}

	@Override
	/**
	 * Updates isOnline to yes when user logs in.
	 * 
	 * @param mobilenumber
	 * @return returns string saying record of particular mobilenumber updated
	 *         successfully.
	 */

	public String updateOnline(String mobilenumber) {

		hibernateUtil.openCurrentSessionwithTransaction();

		hibernateUtil.getCurrentSession()
				.createQuery("update User  set isOnline = 'yes' where mobilenumber='" + mobilenumber + "'")
				.executeUpdate();

		hibernateUtil.closeCurrentSessionwithTransaction();

		return "User record updated successfully with mobilenumber:" + mobilenumber;

	}

	@Override
	/**
	 * Resets isOnline column in user_table to no when user disconnected..
	 * 
	 * @param username
	 * @return String saying record of particular username saved successfully.
	 */
	public String statusOffline(String username) {

		hibernateUtil.openCurrentSessionwithTransaction();

		hibernateUtil.getCurrentSession()
				.createQuery("update User  set isOnline = 'no' where username='" + username + "'").executeUpdate();

		hibernateUtil.closeCurrentSessionwithTransaction();

		return "User record updated successfully with username:" + username;
	}

}