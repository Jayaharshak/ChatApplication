/*
* class :UserDaoImpl
* 
* Purpose: impliments UserDao interface.
*
*/
package com.ofs.frontierchat.dao;

import java.util.List;

import com.ofs.frontierchat.model.User;
import com.ofs.frontierchat.util.HibernateUtil;

/**
 * Frontierchat project
 * 
 * package com.ofs.frontierchat.dao
 * 
 * UserDaoImpl.java
 * 
 * Purpose: It implements the UserDao interface.
 *
 * @author Jayaharsha
 *
 */
public class UserDaoImpl implements UserDao {

	HibernateUtil hibernateUtil = new HibernateUtil();

	/**
	 * fetch the data from user_table with given mobilenumber and password.
	 * 
	 * @param mobilenumber
	 * @param password
	 * @return user record.
	 */
	@Override
	public User findUserByMobilenumber(String mobilenumber, String password) {
		hibernateUtil.openCurrentSession();

		User user = (User) hibernateUtil.getCurrentSession()
				.createQuery("from User where mobilenumber='" + mobilenumber + "' and password ='" + password + "'")
				.uniqueResult();

		hibernateUtil.closeCurrentSession();

		return user;
	}

	/**
	 * Adding new user details to database on signup.
	 * 
	 * @param user
	 * @return String saying record of particular id saved successfully.
	 */
	@Override
	public String addUser(User user) {

		hibernateUtil.openCurrentSessionwithTransaction();

		Integer id = (Integer) hibernateUtil.getCurrentSession().save(user);

		hibernateUtil.closeCurrentSessionwithTransaction();

		return "User record saved successfully with id:" + id;
	}

	/**
	 * Returns total contacts list from user_table. Returns list.
	 */
	@Override
	public List<User> getContactList() {

		hibernateUtil.openCurrentSession();

		List<User> contact_list = hibernateUtil.getCurrentSession().createQuery("from User").list();

		hibernateUtil.closeCurrentSession();

		return contact_list;
	}

	/**
	 * Updates isOnline to yes when user logs in.
	 * 
	 * @param mobilenumber
	 * @return returns string saying record of particular mobilenumber updated
	 *         successfully.
	 */
	@Override
	public String updateOnline(String mobilenumber) {

		hibernateUtil.openCurrentSessionwithTransaction();

		hibernateUtil.getCurrentSession()
				.createQuery("update User  set isOnline = 'yes' where mobilenumber='" + mobilenumber + "'")
				.executeUpdate();

		hibernateUtil.closeCurrentSessionwithTransaction();

		return "User record updated successfully with mobilenumber:" + mobilenumber;

	}

	/**
	 * Resets isOnline column in user_table to no when user disconnected..
	 * 
	 * @param username
	 * @return String saying record of particular username saved successfully.
	 */
	@Override
	public String statusOffline(String username) {

		hibernateUtil.openCurrentSessionwithTransaction();

		hibernateUtil.getCurrentSession()
				.createQuery("update User  set isOnline = 'no' where username='" + username + "'").executeUpdate();

		hibernateUtil.closeCurrentSessionwithTransaction();

		return "User record updated successfully with username:" + username;
	}

}