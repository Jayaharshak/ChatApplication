/*
* interface :ChatDao
* 
* Purpose: Data Access layer for chat_log saving and retrieving
*/
package com.ofs.frontierchat.dao;

import java.util.List;

import com.ofs.frontierchat.model.ChatLog;

/**
 * Frontierchat project
 * 
 * ChatDao.java
 * 
 * package com.ofs.frontierchat.dao
 * 
 * Purpose: interface for data access.
 *
 * @author Jayaharsha
 *
 */
public interface ChatDao {

	public String saveChatLog(ChatLog newlog);

	public List<ChatLog> getChatLogByUsername(String fromuser, String touser);

}
