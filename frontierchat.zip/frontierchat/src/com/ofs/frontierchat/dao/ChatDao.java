package com.ofs.frontierchat.dao;

import java.util.List;

import com.ofs.frontierchat.model.chatLog;

public interface ChatDao {

	public String saveChatLog(chatLog newlog);

	public List<chatLog> getChatLogByUsername(String fromuser, String touser);

}
