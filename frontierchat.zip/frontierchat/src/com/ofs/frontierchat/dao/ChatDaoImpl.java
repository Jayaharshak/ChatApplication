/*
* class :ChatDaoImpl
* 
* Purpose: impliments ChatDao interface.
*
*/
package com.ofs.frontierchat.dao;

import java.util.List;

import com.ofs.frontierchat.model.ChatLog;
import com.ofs.frontierchat.util.HibernateUtil;

/**
 * Frontierchat project
 * 
 * package com.ofs.frontierchat.dao
 * 
 * ChatDaoImpl.java
 * 
 * Purpose: Implements ChatDao Interface.
 *
 * @author Jayaharsha
 *
 */
public class ChatDaoImpl implements ChatDao {

	HibernateUtil hibernateUtil = new HibernateUtil();

	/**
	 * Saves chat log to database table chat_log
	 * 
	 * @param newlog
	 * @return String saying chatlog of particular id saved successfully.
	 */
	@Override
	public String saveChatLog(ChatLog newlog) {

		hibernateUtil.openCurrentSessionwithTransaction();

		Integer logid = (Integer) hibernateUtil.getCurrentSession().save(newlog);

		hibernateUtil.closeCurrentSessionwithTransaction();

		return "Chat log saved successfully with logId:" + logid;
	}

	/**
	 * Returns list of chat history between particular users.
	 * 
	 * @param fromuser
	 * @param touser
	 * @return returns a list personalchatlog
	 */
	@Override
	public List<ChatLog> getChatLogByUsername(String fromuser, String touser) {

		hibernateUtil.openCurrentSession();

		List<ChatLog> personalchatlog = hibernateUtil.getCurrentSession()
				.createQuery("from ChatLog where fromuser='" + fromuser + "' or touser ='" + fromuser + "'").list();

		hibernateUtil.closeCurrentSession();

		return personalchatlog;

	}

}
