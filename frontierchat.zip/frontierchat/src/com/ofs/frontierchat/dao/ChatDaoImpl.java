package com.ofs.frontierchat.dao;

import java.util.List;

import com.ofs.frontierchat.model.chatLog;
import com.ofs.frontierchat.util.HibernateUtil;

public class ChatDaoImpl implements ChatDao {

	HibernateUtil hibernateUtil = new HibernateUtil();

	@Override
	/**
	 * Saves chat log to database table chat_log
	 * 
	 * @param newlog
	 * @return String saying chatlog of particular id saved successfully.
	 */
	public String saveChatLog(chatLog newlog) {

		hibernateUtil.openCurrentSessionwithTransaction();

		Integer logid = (Integer) hibernateUtil.getCurrentSession().save(newlog);

		hibernateUtil.closeCurrentSessionwithTransaction();

		return "Chat log saved successfully with logId:" + logid;
	}

	@Override
	/**
	 * Returns list of chat history between particular users.
	 * 
	 * @param fromuser
	 * @param touser
	 * @return returns a list personalchatlog
	 */
	public List<chatLog> getChatLogByUsername(String fromuser, String touser) {

		hibernateUtil.openCurrentSession();

		List<chatLog> personalchatlog = hibernateUtil.getCurrentSession()
				.createQuery("from chatLog where fromuser='" + fromuser + "' or touser ='" + fromuser + "'").list();

		hibernateUtil.closeCurrentSession();

		return personalchatlog;

	}

}
