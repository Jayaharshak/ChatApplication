/*
* interface :UserDao 
* 
* Purpose: Interface for data access
*
*/
package com.ofs.frontierchat.dao;

import java.util.List;

import com.ofs.frontierchat.model.User;

/**
 * Frontierchat project
 * 
 * UserDao.java
 * 
 * package com.ofs.frontierchat.dao
 * 
 * Purpose: interface for data accessing from database.
 *
 * @author Jayaharsha
 *
 */
public interface UserDao {

	public User findUserByMobilenumber(String mobilenumber, String password);

	public String addUser(User user);

	public List<User> getContactList();

	public String updateOnline(String mobilenumber);

	public String statusOffline(String username);

}
