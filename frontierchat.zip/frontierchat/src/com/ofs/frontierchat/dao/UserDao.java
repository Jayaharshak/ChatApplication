package com.ofs.frontierchat.dao;

import java.util.List;

import com.ofs.frontierchat.model.User;

public interface UserDao {

	public User findUserByMobilenumber(String mobilenumber, String password);

	public String addUser(User user);

	public List<User> getContactList();

	public String updateOnline(String mobilenumber);

	public String statusOffline(String username);

}
