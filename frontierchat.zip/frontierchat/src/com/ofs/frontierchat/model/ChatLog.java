/*
* class :ChatLog  
* 
* Purpose: Entity class to map with chat_log table
*
*/
package com.ofs.frontierchat.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * frontierchat
 * 
 * package com.ofs.frontierchat.model
 * 
 * class ChatLog
 * 
 * @author jayaharsha.k
 */

@Entity
@Table(name = "chat_log")
public class ChatLog {

	@Id
	@GeneratedValue
	@Column(name = "logid")
	private int logid;

	@Column(name = "fromuser")
	private String fromuser;

	@Column(name = "touser")
	private String touser;

	@Column(name = "chatcontent")
	private String chatcontent;

	@Column(name = "chattime")
	private String chattime;

	@Column(name = "type")
	private String type;

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public int getLogid() {
		return logid;
	}

	public void setLogid(int logid) {
		this.logid = logid;
	}

	public String getFromuser() {
		return fromuser;
	}

	public void setFromuser(String fromuser) {
		this.fromuser = fromuser;
	}

	public String getTouser() {
		return touser;
	}

	public void setTouser(String touser) {
		this.touser = touser;
	}

	public String getChatcontent() {
		return chatcontent;
	}

	public void setChatcontent(String chatcontent) {
		this.chatcontent = chatcontent;
	}

	public String getChattime() {
		return chattime;
	}

	public void setChattime(String chattime) {
		this.chattime = chattime;
	}

}
