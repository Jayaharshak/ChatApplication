
package com.ofs.frontierchat.controller;

import java.util.List;

import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;

import org.codehaus.jettison.json.JSONObject;

import com.ofs.frontierchat.encryption.TrippleDes;
import com.ofs.frontierchat.model.User;
import com.ofs.frontierchat.service.UserService;
import com.ofs.frontierchat.service.UserServiceImpl;

/**
 * Frontierchat project UserController.java Purpose: Controller which maps url
 * to java methods.
 *
 * @author Jayaharsha
 *
 */

@Path("/user")
public class UserController {

	UserService userService = new UserServiceImpl();

	@Path("/auth")
	@GET
	@Produces("application/json")
	public String authUserByMobilenumber(@QueryParam("mobilenumber") String mobilenumber,
			@QueryParam("password") String password) throws Exception {

		String response = "";

		JSONObject jsonObject = new JSONObject();

		TrippleDes td = new TrippleDes();

		String encryptedpassword = td.encrypt(password);

		User user = userService.findUserByMobilenumber(mobilenumber, encryptedpassword);

		if (mobilenumber.equals(user.getMobilenumber()) && encryptedpassword.equals(user.getPassword())) {

			jsonObject.put("Status", "Success");

			jsonObject.put("username", user.getUsername());

			jsonObject.put("mobilenumber", user.getMobilenumber());

			jsonObject.put("id", user.getId());

			jsonObject.put("isOnline", user.getIsOnline());

			response = jsonObject.toString();

		} else {

			jsonObject.put("Status", "Failure");
			response = jsonObject.toString();

		}

		return response;
	}

	@Path("/add")
	@GET
	@Consumes("text/html")
	@Produces("text/html")
	/**
	 * addUser when signup with details and saving details in user_table .
	 *
	 * @param mobilenumber
	 * @param password
	 * @param username
	 *
	 * @return response of addUser method of userService interface.
	 */
	public String addUser(

			@QueryParam("username") String username, @QueryParam("mobilenumber") String mobilenumber,
			@QueryParam("password") String password

	) throws Exception {

		User user = new User();

		TrippleDes td = new TrippleDes();

		user.setUsername(username);

		user.setMobilenumber(mobilenumber);

		user.setIsOnline("no");

		String encryptedpassword = td.encrypt(password);

		user.setPassword(encryptedpassword);

		return userService.addUser(user);

	}

	@Path("/contactList")
	@GET
	@Produces("application/json")
	/**
	 * fetch the about total user details from user_table.
	 *
	 * @return list of records.
	 */
	public List<User> getContactList() {

		return userService.getContactList();
	}

	@Path("/updatestatus")
	@GET
	/**
	 * updates the user table isOnline to yes when user logs in.
	 * 
	 * @param mobilenumber
	 *            as parameter to refer the row.
	 *
	 * @return updateOnline method from userService interface.
	 */
	public String updateOnline(@QueryParam("mobilenumber") String mobilenumber) throws Exception {

		return userService.updateOnline(mobilenumber);
	}

}