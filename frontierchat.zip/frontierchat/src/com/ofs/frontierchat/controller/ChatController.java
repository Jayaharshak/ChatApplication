package com.ofs.frontierchat.controller;

import java.util.List;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.QueryParam;

import com.ofs.frontierchat.model.chatLog;
import com.ofs.frontierchat.service.ChatService;
import com.ofs.frontierchat.service.ChatServiceImpl;

/**
 * Frontierchat project ChatController.java Purpose: Controller which maps url
 * to java methods.
 *
 * @author Jayaharsha
 *
 */

@Path("/chat")
public class ChatController {

	ChatService chatService = new ChatServiceImpl();

	@Path("/savechatlog")
	@GET
	/**
	 * fetch the data from user_table with given mobilenumber and password.
	 * 
	 * @param fromuser
	 *            who is sending message
	 * @param touser
	 *            who is receiving message
	 * @param chatcontent
	 *            content of chat
	 * @param chattime
	 * @return returns response of string weather chat log saved or not.
	 */
	public String saveChatLog(@QueryParam("fromuser") String fromuser, @QueryParam("touser") String touser,
			@QueryParam("chatcontent") String chatcontent, @QueryParam("chattime") String chattime) {
		chatLog newlog = new chatLog();

		newlog.setFromuser(fromuser);

		newlog.setChatcontent(chatcontent);

		newlog.setTouser(touser);

		newlog.setChattime(chattime);

		return chatService.saveChatLog(newlog);

	}

	@Path("/getchatlog")
	@GET
	/**
	 * fetch the data from user_table with given mobilenumber and password.
	 * 
	 * @param fromuser
	 * @param touser
	 * @return user record returns the list of chat log between two users. .
	 */
	public List<chatLog> getChatLogByUsername(@QueryParam("fromuser") String fromuser,
			@QueryParam("touser") String touser) throws Exception {

		return chatService.getChatLogByUsername(fromuser, touser);
	}

}
