/*
* class :ChatController 
* 
* Purpose: Controller for chat log functionalities
*
*/

package com.ofs.frontierchat.controller;

import java.util.List;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.QueryParam;

import com.ofs.frontierchat.model.ChatLog;
import com.ofs.frontierchat.service.ChatService;
import com.ofs.frontierchat.service.ChatServiceImpl;

/**
 * Frontierchat project
 * 
 * package com.ofs.frontierchat.controller
 * 
 * ChatController.java
 * 
 * Purpose: Controller which maps url to java methods.
 *
 * @author Jayaharsha
 *
 */

@Path("/chat")
public class ChatController {

	ChatService chatService = new ChatServiceImpl();

	/**
	 * saves chatlog to chat_log table.
	 * 
	 * @param fromuser
	 *            who is sending message
	 * @param touser
	 *            who is receiving message
	 * @param chatcontent
	 *            content of chat
	 * @param chattime
	 * @param type
	 * @return returns response of string weather chat log saved or not.
	 */
	@Path("/savechatlog")
	@GET
	public String saveChatLog(@QueryParam("fromuser") String fromuser, @QueryParam("touser") String touser,
			@QueryParam("chatcontent") String chatcontent, @QueryParam("chattime") String chattime,
			@QueryParam("type") String type) {

		ChatLog newlog = new ChatLog();

		newlog.setFromuser(fromuser);

		newlog.setChatcontent(chatcontent);

		newlog.setTouser(touser);

		newlog.setChattime(chattime);

		newlog.setType(type);

		return chatService.saveChatLog(newlog);

	}

	/**
	 * fetch the data from user_table with given username.
	 * 
	 * @param fromuser
	 * @param touser
	 * @return user record returns the list of chat log between two users. .
	 */
	@Path("/getchatlog")
	@GET
	public List<ChatLog> getChatLogByUsername(@QueryParam("fromuser") String fromuser,
			@QueryParam("touser") String touser) throws Exception {

		return chatService.getChatLogByUsername(fromuser, touser);
	}

}
