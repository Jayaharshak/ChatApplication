 $('.message a').click(function(){
   $('form').animate({height: "toggle", opacity: "toggle"}, "slow");
});
 
/* function showProfile() {
	    var x = document.getElementById("myDIV");
	    var y = document.getElementById("log");
	    var z = document.getElementById("prependeddiv");
	        x.style.display = "block";
	        y.style.display = "none";
	        z.style.display = "none";
}
 
 function hideProfile() {
	 
	 var x = document.getElementById("myDIV");
	 var y = document.getElementById("log");
	 var z = document.getElementById("prependeddiv");
	 x.style.display = "none";
	 y.style.display = "block";
	 z.style.display = "block";
 }
 
 hideProfile();*/