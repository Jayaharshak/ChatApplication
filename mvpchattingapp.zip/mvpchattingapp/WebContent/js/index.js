 $('.message a').click(function(){
   $('form').animate({height: "toggle", opacity: "toggle"}, "slow");
});
 
 var openFile = function(event) {
	    var input = event.target;

	    var reader = new FileReader();
	    reader.onload = function(){
	      var dataURL = reader.result;
	      var output = document.getElementById('output');
	      output.src = dataURL;
	    };
	    reader.readAsDataURL(input.files[0]);
	  };
	  
	  
 
/* function showProfile() {
	    var x = document.getElementById("myDIV");
	    var y = document.getElementById("log");
	    var z = document.getElementById("prependeddiv");
	        x.style.display = "block";
	        y.style.display = "none";
	        z.style.display = "none";
}
 
 function hideProfile() {
	 
	 var x = document.getElementById("myDIV");
	 var y = document.getElementById("log");
	 var z = document.getElementById("prependeddiv");
	 x.style.display = "none";
	 y.style.display = "block";
	 z.style.display = "block";
 }
 
 hideProfile();*/