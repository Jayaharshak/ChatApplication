var app = angular.module('myApp', []);

app.controller("logincontroller",['$scope','$http',function($scope,$http){
	$scope.loginpagebool = true;
	$scope.chatpagebool =false;
	$scope.messageheadbool = false;
	$scope.chatroomheadbool = true;
	$scope.textingdivbool = true;
	$scope.filesendingdivbool = false;
	
	$scope.profiledivbool = false;
	$scope.historydivbool = true;
	$scope.textareadivbool = true
	
	$scope.yes = true;
	$scope.no = false;
	$scope.displayname_icon = false;
	dateandtime = $scope.dateandtime;
	
	/*instance of date to daiplay time and date.*/
	$scope.CurrentDate = new Date();
	
	
	
	$scope.getContactList = function() {
		
		var url="http://localhost:8080/mvpchattingapp/rest/user/contactList";
		$http({
		method: 'GET',
		url: url
			}).then(function successCallback(response) {
			console.log("-----success response is-----",response);
			$scope.details = response.data;
			}, function errorCallback(response) {
			console.log("-------err---",response);
			});
	}
	
	$scope.onLogin=function(mobilenumber,password)	{	
		
		
		//GET request 
		var url = "http://localhost:8080/mvpchattingapp/rest/user/auth?mobilenumber="+mobilenumber+"&password="+password;
		
		console.log("##-----url--",url)
		$http({
		method: 'GET',
		url: url
		}).then(function successCallback(response) {
			
			var url="http://localhost:8080/mvpchattingapp/rest/user/updatestatus?mobilenumber="+mobilenumber;
			$http({
			method: 'GET',
			url: url
				}).then(function successCallback(response) {
				console.log("user status updated",response);
				
				}, function errorCallback(response) {
				console.log("user status not updated",response);
				});
			
			var response = JSON.parse(response.data);
		if(response.Status == "Success"){
		$scope.loginpagebool=false;
		$scope.chatpagebool= true;
		$scope.username= response.username;
		$scope.mobilenumber = response.mobilenumber;
		$scope.id = response.id;
		$scope.Online = response.isOnline;
		$scope.connect();
		$scope.getContactList();
		
		} 
		
		else {
		$scope.Status = 'Invalid user';
		
		}
		console.log(response);
		}, 
		
		function errorCallback(response) {
		$scope.Status = 'Invalid user';
		});
		//$scope.signinemail="";
		//$scope.signinpassword="";
		
	}
	
	$scope.onSignup = function(signupusername,signupmobilenumber,signuppassword) {
		
		var url = "http://localhost:8080/mvpchattingapp/rest/user/add?username="+signupusername+"&mobilenumber="+signupmobilenumber+"&password="+signuppassword;
			
			console.log("##-----url--",url)
			$http({
			method: 'GET',
			url: url
			}).then(function successCallback(response) {
				/*var returnresponse = JSON.parse(response.data);*/
			if(response.status ==200){
			$scope.signupStatus ="Successfully registered";
			$scope.loginpagebool = true;
			$scope.chatpagebool = false;
			
			
			$scope.signupusername = "";
			$scope.signupmobilenumber ="";
			$scope.signuppassword="";
			
			
			}
			else {
				$scope.signupStatus = "Registration failed !!";
				}
		
			},
			
			function errorCallback(response) {
				$scope.signupStatus = "Registration failed !!";
				});
			
		}
	
	
	
   /* $scope.users = []; //declare an empty array
    
    $http.get("js/data.json").success(function(response) {
        $scope.users = response; //ajax request to fetch data into $scope.data
    });
    */
   
	var ws;
	$scope.connect = function(){
		username = $scope.username;
		/*var connectionName = user.Empname;*/
		/*var username = document.getElementById("username").value;*/
		ws = new WebSocket("ws://" + document.location.host + "/mvpchattingapp/chat/" + username);
		
		ws.onmessage = function(event) {
		    var log = document.getElementById("log");
		    
		    
		    	/*event.time = document.getElementById("dateandtime").value;*/
		        console.log("this is event.data"+event.data);
		        var message = JSON.parse(event.data);
		        message.dateAndTime = $scope.CurrentDate;
		        /*$scope.displaytime = getElementById('dateandtime').value;*/
		        /*console("this is displaying time"+displaytime);*/
		        console.log(message);
		        console.log("touser:"+message.to);
		        console.log("fromuser:"+message.from);
		        console.log("chatcontent:"+message.content);
		        console.log("chattime:"+message.dateAndTime);
		        
		        var logdiv = document.getElementById('log');
			    // Make a new div
			    Child = document.createElement('div');

			    var attr = document.createAttribute("class");       // Create a "class" attribute
			    attr.value = "appendedclass2";  
			    
			     // Set the value of the class attribute
			    Child.setAttributeNode(attr);
			// Give the new div some content
			Child.innerHTML = message.content;

			// Jug it into the parent element
			logdiv.appendChild(Child);
		     
		       /* log.innerHTML += message.from + " : " + message.content + "\n";*/
			   /* }*/
		        
		        // here http request to save chat log to database.
		        var url = "http://localhost:8080/mvpchattingapp/rest/user/savechatlog?fromuser="+message.from+"&touser="+message.to+"&chatcontent="+message.content+"&chattime="+message.dateAndTime;
		        $http({
					method: 'GET',
					url: url
					})
		        
		        
		    };
		    
	}
	
	$scope.send = function() {
		/*var log = document.getElementById("log");*/
		var content = document.getElementById("msg").value;
	    /*var to = document.getElementById("to").value;*/
	    var to = $scope.displayname;
	    /*var time = document.getElementById("dateandtime").value;*/
	    var json = JSON.stringify({
	        "to":to,
	        "content":content
	        /*"time":time*/
	    });
	    /*$("#log").append("<p style='color:red' class='pull-right'>"+ content +"</p>");*/
	    console.log("our data" + json);
	    ws.send(json);
	    
	    //creating element to append this message.
	    var logdiv = document.getElementById('log');
	    // Make a new div
	    Child = document.createElement('div');

	    var att = document.createAttribute("class");       // Create a "class" attribute
	    att.value = "appendedclass";  
	    
	     // Set the value of the class attribute
	    Child.setAttributeNode(att);
	// Give the new div some content
	Child.innerHTML = content;

	// Jug it into the parent element
	logdiv.appendChild(Child);
	    
	    /*log.innerHTML += "Me : " + content + "\n";*/
	    document.getElementById("msg").value = ""
	};
	
	 
	 
	/*$scope.sendfile = function() {
		
		var fr = new FileReader();
		
		var to = $scope.displayname;
		var content = getBase64Image(document.getElementById("file") );
		var img = document.getElementById("file");
		
		var canvas = document.createElement("canvas");
		  canvas.width = img.width;
		  canvas.height = img.height;
		 
		  // Copy the image contents to the canvas
		  var ctx = canvas.getContext("2d");
		  ctx.drawImage(img, 0, 0);
		 
		  // Get the data-URL formatted image
		  // Firefox supports PNG and JPEG. You could check img.src to guess the
		  // original format, but be aware the using "image/jpg" will re-encode the image.
		  var dataURL = canvas.toDataURL("image/png");
		   
		  var content = dataURL;
		  
		  
			  var JSONimg = {
					  "to" :to,
			    "type" : 'img',
			    "content" : content
			  }
			  ws.send(JSON.stringify(JSONimg));
			
		
	}*/
	
	 $scope.onSelectingContact = function(user) {
			
			$scope.displayname = user.username ;
			$scope.displayname_icon = true;
			$scope.messageheadbool = true;
			$scope.chatroomheadbool = false;
			displayname = $scope.displayname;
			
			var url = "http://localhost:8080/mvpchattingapp/rest/user/getchatlog?fromuser="+username+"&touser ="+displayname;
			$http({
				method: 'GET',
				url: url
					}).then(function successCallback(response) {
					console.log("-----here is on selecting contact list respo-"+response);
					$scope.chatlogs = response.data;
					/*chatlogs = [];
					var chatlogs = response.data;
					var response = JSON.parse(response.data);
					console.log("parsed response"+response);
					console.log("length property"+chatlogs.length);
					
					for (i=0;i,chatlogs.length;i++) {
						
						console.log("inside for loop"+chatlogs[i]);
						if(chatlogs[i].fromuser == displayname && chatlogs[i].touser ==username) {
							
							// printing message on right side of div
							
							var logdiv = document.getElementById('log');
						    // Make a new div
						    Child = document.createElement('div');

						    var att = document.createAttribute("class");       // Create a "class" attribute
						    att.value = "appendedclass2";  
						    
						     // Set the value of the class attribute
						    Child.setAttributeNode(att);
						// Give the new div some content
						Child.innerHTML = chatlogs[i].chatcontent;

						// Jug it into the parent element
						logdiv.appendChild(Child);
							
						} else if (chatlogs[i].fromuser == username && chatlogs[i].touser ==displayname) {
							
							// printing message on left side div
							var logdiv = document.getElementById('log');
						    // Make a new div
						    Child = document.createElement('div');

						    var att = document.createAttribute("class");       // Create a "class" attribute
						    att.value = "appendedclass";  
						    
						     // Set the value of the class attribute
						    Child.setAttributeNode(att);
						// Give the new div some content
						Child.innerHTML = chatlogs[i].chatcontent;

						// Jug it into the parent element
						logdiv.appendChild(Child);
							
						}
						else {
							
							console.log('crystal clear error!!');
						};
						
						
						
					}*/
					console.log(response.data);
					 /*$("#log").prepend("<ul><li id = 'prependeddiv' ng-repeat='chatlog in chatlogs'>From:{{chatlog.fromuser}}..To:{{chatlog.touser}}..{{chatlog.chatcontent}} {{chatlog.time}]</li></ul>");*/
					
					});
			
		};
		
	
	$scope.onSelectingGroupchat = function() {
		
		
		$scope.messageheadbool = false;
		$scope.chatroomheadbool = true;
	}
	
	$scope.showfilesendingdiv = function() {
		
		$scope.textingdivbool = false;
		$scope.filesendingdivbool = true;
	}
	
	$scope.showtextingdiv = function() {
		
		$scope.textingdivbool = true;
		$scope.filesendingdivbool = false;
		
	}
	
	$scope.showProfile = function() {
		
		$scope.profiledivbool = true;
		$scope.historydivbool = false;
		$scope.textareadivbool = false;
	};
	
	$scope.hideProfile = function() {
		
		$scope.profiledivbool = false;
		$scope.historydivbool = true;
		$scope.textareadivbool = true;
		
	};
	
	 $scope.openFile = function(event) {
		    var input = event.target;

		    var reader = new FileReader();
		    reader.onload = function(){
		      var dataURL = reader.result;
		      var output = document.getElementById('output');
		      output.src = dataURL;
		    };
		    reader.readAsDataURL(input.files[0]);
		  };
		  
		  
		
	
}]);


/*app.directive('mainArea', function() {
    return {
        restrict: "E",
        template: "<div>"+
            "<div id='mainDiv'> </div>" +
            "<button data-ng-click='append()'>Add</button>" +
        "</div>",
        controller: function($scope, $element, $attrs) {
            $scope.append = function() {
                var p = angular.element("<p />");
                p.text("Appended");
                $element.find("div").append(p);
            }
        }
    }
});*/


/*
$scope.getBase64Image = function(img) {
	  // Create an empty canvas element
	  var canvas = document.createElement("canvas");
	  canvas.width = img.width;
	  canvas.height = img.height;
	 
	  // Copy the image contents to the canvas
	  var ctx = canvas.getContext("2d");
	  ctx.drawImage(img, 0, 0);
	 
	  // Get the data-URL formatted image
	  // Firefox supports PNG and JPEG. You could check img.src to guess the
	  // original format, but be aware the using "image/jpg" will re-encode the image.
	  var dataURL = canvas.toDataURL("image/png");
	  return dataURL;
	}
*/

    /*Controller for chat page */

/*app.controller('sidebarcontroller', ['$scope', '$http', function($scope, $http) {
	$scope.y = true;
	$scope.n = false;
	$scope.displayname_icon = false;
	dateandtime = $scope.dateandtime;
	
	instance of date to daiplay time and date.
	$scope.CurrentDate = new Date();
	
    $scope.users = []; //declare an empty array
    
    $http.get("js/data.json").success(function(response) {
        $scope.users = response; //ajax request to fetch data into $scope.data
    });
    
    $scope.onSelectingContact = function(user) {
		
		$scope.displayname = user.Empname ;
		$scope.displayname_icon = true;
		$scope.connect(user);
	};
	
	var ws;
	$scope.connect = function(){
		
		var connectionName = user.Empname;
		var username = document.getElementById("username").value;
		ws = new WebSocket("ws://" + document.location.host + "/mvpchattingapp/chat/" + username);
		
		ws.onmessage = function(event) {
		    var log = document.getElementById("log");
		    	event.time = document.getElementById("dateandtime").value;
		        console.log(event.data);
		        var message = JSON.parse(event.data);
		        message.dateAndTime = $scope.CurrentDate;
		        console.log(message);
		        message.time = document.getElementById("dateandtime").value;
		        recylejson = JSON.stringify(message);
		        console.log("recycled json" + recyclejson);
		        console.log("this message" +message);
		        log.innerHTML += message.from + " : " + message.content + "\n";
		    };
		    
	}
	
	$scope.send = function() {
		
		var content = document.getElementById("msg").value;
	    var to = document.getElementById("to").value;
	    var to = $scope.displayname;
	    var time = document.getElementById("dateandtime").value;
	    var json = JSON.stringify({
	        "to":to,
	        "content":content
	        "time":time
	    });
	    console.log("our data" + json);
	    ws.send(json);
	    log.innerHTML += "Me : " + content + "\n";
	    document.getElementById("msg").value = ""
	}
	

}]);
*/

