var app = angular.module('myApp', []);

app.controller("logincontroller",['$scope', '$rootScope','$http',function($scope,$rootScope,$http){
	$scope.loginpagebool = true;
	$scope.chatpagebool =false;
	$scope.messageheadbool = false;
	$scope.chatroomheadbool = true;
	$scope.textingdivbool = true;
	$scope.filesendingdivbool = false;

	$scope.profiledivbool = false;
	$scope.historydivbool = true;
	$scope.textareadivbool = true

	$scope.yes = true;
	$scope.no = false;
	$scope.displayname_icon = false;
	dateandtime = $scope.dateandtime;

	/*instance of date to daiplay time and date.*/
	$scope.CurrentDate = new Date();



	$scope.getContactList = function() {

		var url="http://localhost:8080/mvpchattingapp/rest/user/contactList";
		$http({
		method: 'GET',
		url: url
			}).then(function successCallback(response) {
			console.log("-----success response is-----",response);
			$scope.details = response.data;
			}, function errorCallback(response) {
			console.log("-------err---",response);
			});
	}

	$scope.onLogin=function(mobilenumber,password)	{


		//GET request
		var url = "http://localhost:8080/mvpchattingapp/rest/user/auth?mobilenumber="+mobilenumber+"&password="+password;

		console.log("##-----url--",url)
		$http({
		method: 'GET',
		url: url
		}).then(function successCallback(response) {

			var url="http://localhost:8080/mvpchattingapp/rest/user/updatestatus?mobilenumber="+mobilenumber;
			$http({
			method: 'GET',
			url: url
				}).then(function successCallback(response) {
				console.log("user status updated",response);

				}, function errorCallback(response) {
				console.log("user status not updated",response);
				});

			var response = JSON.parse(response.data);
		if(response.Status == "Success"){
		$scope.loginpagebool=false;
		$scope.chatpagebool= true;
		$rootScope.username= response.username;
		$scope.mobilenumber = response.mobilenumber;
		$scope.id = response.id;
		$scope.Online = response.isOnline;
		$scope.connect();
		$scope.getContactList();

		
		
		}

		else {
		$scope.Status = 'Invalid user';

		}
		console.log(response);
		},

		function errorCallback(response) {
		$scope.Status = 'Invalid user';
		});
		//$scope.signinemail="";
		//$scope.signinpassword="";

	}

	$scope.onSignup = function(signupusername,signupmobilenumber,signuppassword) {

		var url = "http://localhost:8080/mvpchattingapp/rest/user/add?username="+signupusername+"&mobilenumber="+signupmobilenumber+"&password="+signuppassword;

			console.log("##-----url--",url)
			$http({
			method: 'GET',
			url: url
			}).then(function successCallback(response) {
				/*var returnresponse = JSON.parse(response.data);*/
			if(response.status ==200){
			$scope.signupStatus ="Successfully registered";
			$scope.loginpagebool = true;
			$scope.chatpagebool = false;


			$scope.signupusername = "";
			$scope.signupmobilenumber ="";
			$scope.signuppassword="";


			}
			else {
				$scope.signupStatus = "Registration failed !!";
				}

			},

			function errorCallback(response) {
				$scope.signupStatus = "Registration failed !!";
				});

		}


	var ws;
	$scope.connect = function(){
		username = $scope.username;
		/*var connectionName = user.Empname;*/
		/*var username = document.getElementById("username").value;*/
		ws = new WebSocket("ws://" + document.location.host + "/mvpchattingapp/chat/" + username);

		ws.onmessage = function(event) {
		    var log = document.getElementById("chatlog");


		    	/*event.time = document.getElementById("dateandtime").value;*/
		        console.log("this is event.data"+event.data);
		        var message = JSON.parse(event.data);
		        message.dateAndTime = $scope.CurrentDate;
		        /*$scope.displaytime = getElementById('dateandtime').value;*/
		        /*console("this is displaying time"+displaytime);*/
		        console.log(message);
		        console.log("touser:"+message.to);
		        console.log("fromuser:"+message.from);
		        console.log("chatcontent:"+message.content);
		        console.log("chattime:"+message.dateAndTime);

		        var logdiv = document.getElementById('log');
			    // Make a new div
			    Child = document.createElement('span');
					Child2 = document.createElement("br");

			    var attr = document.createAttribute("class");       // Create a "class" attribute
			    attr.value = "appendedclass2 glyphicons glyphicons-chat";

			     // Set the value of the class attribute
			    Child.setAttributeNode(attr);
			// Give the new div some content
			Child.innerHTML = message.from+":"+message.content;

			// Jug it into the parent element
			logdiv.appendChild(Child);
			logdiv.appendChild(Child2);

		       /* log.innerHTML += message.from + " : " + message.content + "\n";*/
			   /* }*/

		        // here http request to save chat log to database.
		        var url = "http://localhost:8080/mvpchattingapp/rest/user/savechatlog?fromuser="+message.from+"&touser="+message.to+"&chatcontent="+message.content+"&chattime="+message.dateAndTime;
		        $http({
					method: 'GET',
					url: url
					})


		    };

	}

	$scope.send = function() {
		/*var log = document.getElementById("log");*/
		var content = document.getElementById("msg").value;
	    /*var to = document.getElementById("to").value;*/
	    var to = $scope.displayname;
	    /*var time = document.getElementById("dateandtime").value;*/
	    var json = JSON.stringify({
	        "to":to,
	        "content":content
	        /*"time":time*/
	    });
	    /*$("#log").append("<p style='color:red' class='pull-right'>"+ content +"</p>");*/
	    console.log("our data" + json);
	    ws.send(json);

	    //creating element to append this message.
	    var logdiv = document.getElementById('log');
	    // Make a new div
	    Child = document.createElement('span');
			Child2 = document.createElement("br");

	    var att = document.createAttribute("class");       // Create a "class" attribute
	    att.value = "appendedclass glyphicons glyphicons-chat";

	     // Set the value of the class attribute
	    Child.setAttributeNode(att);
	// Give the new div some content
	Child.innerHTML = content;

	// Jug it into the parent element
	logdiv.appendChild(Child);
	logdiv.appendChild(Child2);


	    /*log.innerHTML += "Me : " + content + "\n";*/
	    document.getElementById("msg").value = ""
	};



	
	 $scope.onSelectingContact = function(user) {

			$rootScope.displayname = user.username ;
			$scope.displayname_icon = true;
			$scope.messageheadbool = true;
			$scope.chatroomheadbool = false;
			displayname = $scope.displayname;
			 $('#log').text("");


			var url = "http://localhost:8080/mvpchattingapp/rest/user/getchatlog?fromuser="+$rootScope.username+"&touser ="+$rootScope.displayname;
			$http({
				method: 'GET',
				url: url
					}).then(function successCallback(response) {
					console.log("-----here is on selecting contact list respo-"+response);
					$scope.chatlogs = response.data;

					var loghistory = response.data;
					console.log(response.data);
					console.log("length of chatlogs"+loghistory.length);
					console.log("first element of chatlogs"+loghistory[0].fromuser);

					for(i=0;i<loghistory.length;i++) {
						if((loghistory[i].fromuser == $rootScope.username && loghistory[i].touser == $rootScope.displayname)){


				            var logdiv = document.getElementById('log');
						    Child = document.createElement('span');
								Child2 = document.createElement("br");

						    var attr = document.createAttribute("class");
						    attr.value = "appendedclass glyphicons glyphicons-chat";


						    Child.setAttributeNode(attr);

						    Child.innerHTML = loghistory[i].chatcontent;

						    logdiv.appendChild(Child);
								logdiv.appendChild(Child2);

				            /*console.log("refined logs"+chatlogs);*/
				        } else if ( (loghistory[i].fromuser == $rootScope.displayname && loghistory[i].touser == $rootScope.username)) {



				            var logdiv = document.getElementById('log');
						    Child = document.createElement('span');
								Child2 = document.createElement('br');

						    var attr = document.createAttribute("class");
						    attr.value = "appendedclass2 glyphicons glyphicons-chat";


						    Child.setAttributeNode(attr);

						    Child.innerHTML = loghistory[i].chatcontent;

						    logdiv.appendChild(Child);
								logdiv.appendChild(Child2);


				        }

					}


			});

			

	 }


	$scope.onSelectingGroupchat = function() {

		$('#log').text("Welcome to Chat room...!!");
		$scope.messageheadbool = false;
		$scope.chatroomheadbool = true;
	}

	$scope.showfilesendingdiv = function() {

		$scope.textingdivbool = false;
		$scope.filesendingdivbool = true;
	}

	$scope.showtextingdiv = function() {

		$scope.textingdivbool = true;
		$scope.filesendingdivbool = false;

	}

	$scope.showProfile = function() {

		$scope.profiledivbool = true;
		$scope.historydivbool = false;
		$scope.textareadivbool = false;
	};

	$scope.hideProfile = function() {

		$scope.profiledivbool = false;
		$scope.historydivbool = true;
		$scope.textareadivbool = true;

	};

	
	
}]);


