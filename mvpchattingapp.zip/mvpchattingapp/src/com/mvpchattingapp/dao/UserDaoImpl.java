package com.mvpchattingapp.dao;

import java.util.List;

import javax.mail.Message;

import com.mvpchattingapp.model.User;
import com.mvpchattingapp.model.chatLog;
import com.mvpchattingapp.util.HibernateUtil;




public class UserDaoImpl implements UserDao{
	
	HibernateUtil hibernateUtil = new HibernateUtil();

	@Override
	public User findUserByMobilenumber(String mobilenumber,String password) {
		hibernateUtil.openCurrentSession();
		
		User user =(User) hibernateUtil.getCurrentSession().createQuery("from User where mobilenumber='"+mobilenumber+"' and password ='"+password+"'").uniqueResult();
		
		hibernateUtil.closeCurrentSession();
		
		return user;
	}

	@Override
	public String addUser(User user) {
		hibernateUtil.openCurrentSessionwithTransaction();
		Integer id = (Integer)hibernateUtil.getCurrentSession().save(user);
		hibernateUtil.closeCurrentSessionwithTransaction();
		return "User record saved successfully with id:"+id;
	}
	
	/*public User getContactList() {
		
		hibernateUtil.openCurrentSession();
		
		User user = (User) hibernateUtil.getCurrentSession().createQuery("from User").uniqueResult();
		
		
		hibernateUtil.closeCurrentSession();
		
		return user;
	}*/
	/*@Override
	public String alterUser(String mobilenumber) {
		hibernateUtil.openCurrentSessionwithTransaction();
		
		
		((User) hibernateUtil.getCurrentSession().createQuery("from User where mobilenumber='"+mobilenumber+"'")).setIsOnline("yes");
		
		return "User record saved successfully with miblenumber:"+mobilenumber;
		
	}*/
	
	public List<User> getContactList()
	{
		hibernateUtil.openCurrentSession();
		List<User> contact_list =hibernateUtil.getCurrentSession().createQuery("from User").list();
		hibernateUtil.closeCurrentSession();
		return contact_list;
	}
	
	public String saveChatLog(chatLog newlog) {
		
		hibernateUtil.openCurrentSessionwithTransaction();
		Integer logid = (Integer)hibernateUtil.getCurrentSession().save(newlog);
		hibernateUtil.closeCurrentSessionwithTransaction();
		return "Chat log saved successfully with logId:"+logid;
	}
	
	@Override
	public List<chatLog> getChatLogByUsername(String fromuser,String touser) {
		
		hibernateUtil.openCurrentSession();
		
		List<chatLog> personalchatlog = hibernateUtil.getCurrentSession().createQuery("from chatLog where fromuser='"+fromuser+"' or touser ='"+fromuser+"'").list();
																		
		hibernateUtil.closeCurrentSession();
		
		return personalchatlog;
		
	}
	
}
