package com.mvpchattingapp.controller;

import java.util.List;

import javax.mail.Message;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;

import org.codehaus.jettison.json.JSONObject;

import com.mvpchattingapp.encryption.TrippleDes;
import com.mvpchattingapp.model.User;
import com.mvpchattingapp.model.chatLog;
import com.mvpchattingapp.service.UserService;
import com.mvpchattingapp.service.UserServiceImpl;

			// for sign in 
@Path("/user")
public class UserController {
	
	UserService userService = new UserServiceImpl();

	@Path("/auth")
	@GET
	@Produces("application/json")
	public String authUserByMobilenumber(
			@QueryParam("mobilenumber") String mobilenumber,
			@QueryParam("password") String password			
			) throws Exception
	{
		
		
		String response="";
		JSONObject jsonObject = new JSONObject();
		//Base64.Encoder enc2= Base64.getEncoder();
		//String password ="pwd";
		// byte[] epassword =enc2.encode(password.getBytes());
		// String pwd2=epassword.toString();
		
		TrippleDes td= new TrippleDes();
		
		String encryptedpassword = td.encrypt(password);
		
		 User user = userService.findUserByMobilenumber(mobilenumber,encryptedpassword);
		 
		if(mobilenumber.equals(user.getMobilenumber()) && encryptedpassword.equals(user.getPassword()))		{
		
		jsonObject.put("Status", "Success");
		jsonObject.put("username", user.getUsername());
		jsonObject.put("mobilenumber", user.getMobilenumber());
		jsonObject.put("id", user.getId());
		jsonObject.put("isOnline", user.getIsOnline());
		
		response = jsonObject.toString();
		/*alterUser(mobilenumber);*/
		
	
		}
		else{
			
			jsonObject.put("Status","Failure");			
			response = jsonObject.toString();
			
		}
		
		return response;
	}
	/*private String alterUser(String mobilenumber) {
		
		return userService.alterUser(mobilenumber);
		// TODO Auto-generated method stub
		
	}*/
	//  for sign up 
	@Path("/add")
	@GET
	@Consumes("text/html")
	@Produces("text/html")
	
	public String addUser(
	
			@QueryParam("username") String username,
			@QueryParam("mobilenumber") String mobilenumber,
			/*@QueryParam("address") String address,
			@QueryParam("email") String email,*/
			@QueryParam("password") String password
			
			) throws Exception
	{
		
			User user = new User();
			TrippleDes td= new TrippleDes();
			
			
			user.setUsername(username);
			/*user.setEmail(email);*/
			user.setMobilenumber(mobilenumber);
			user.setIsOnline("no");
			/*user.setAddress(address);*/
			/*Base64.Encoder enc= Base64.getEncoder();
			String password ="password";
			 byte[] epassword =enc.encode(password.getBytes());
			 String pwd2=epassword.toString();
			user.setPwd(pwd2);*/
			
			String encryptedpassword = td.encrypt(password);
			
			
			user.setPassword(encryptedpassword);
			
			
			return userService.addUser(user);
		
	}
	
	//Getting contact list from database
	@Path("/contactList")
	@GET
	@Produces("application/json")
	public List<User> getContactList(){
			 
		return userService.getContactList();		
		}
	
	//Saving chat log to database
	@Path("/savechatlog")
	@GET
	public String saveChatLog (
			@QueryParam("fromuser") String fromuser,
			@QueryParam("touser") String touser,
			@QueryParam("chatcontent") String chatcontent,
			@QueryParam("chattime") String chattime
			)
			 {
		chatLog newlog = new chatLog();
		newlog.setFromuser(fromuser);
		newlog.setChatcontent(chatcontent);
		newlog.setTouser(touser);
		newlog.setChattime(chattime);
		
		return userService.saveChatLog(newlog);
		
			 }
	
	@Path("/getchatlog")
	@GET
	public List<chatLog> getChatLogByUsername(
			@QueryParam("fromuser") String fromuser,
			@QueryParam("touser") String touser
			) throws Exception
		{
		return userService.getChatLogByUsername(fromuser,touser);
		}
	
	
	@Path("/updatestatus")
	@GET
	public String updateOnline(
			@QueryParam("mobilenumber") String mobilenumber
			) throws Exception
		{
		 	return userService.updateOnline(mobilenumber);
		}
	
	
	}
	
