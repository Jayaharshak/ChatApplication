package com.mvpchattingapp.service;

import java.util.List;

import javax.mail.Message;

import com.mvpchattingapp.dao.UserDao;
import com.mvpchattingapp.dao.UserDaoImpl;
import com.mvpchattingapp.model.User;
import com.mvpchattingapp.model.chatLog;

public class UserServiceImpl implements UserService{
	
	UserDao userDao = new UserDaoImpl();

	@Override
	public User findUserByMobilenumber(String mobilenumber, String password) {
	
		return userDao.findUserByMobilenumber(mobilenumber,password);
	}

	@Override
	public String addUser(User user) {
		
		return userDao.addUser(user);
	}
	
	@Override
	public List<User> getContactList() {
		
		return userDao.getContactList();
	}
	
	public String saveChatLog(chatLog newlog) {
		
		return userDao.saveChatLog(newlog);
	}
	
	/*@Override
	public String alterUser(String mobilenumber) {
		
		return userDao.alterUser(mobilenumber);
	}*/
	
	@Override
	public List<chatLog> getChatLogByUsername(String fromuser,String touser) {
		
		return userDao.getChatLogByUsername(fromuser, touser);
	}
	
	@Override
	public String updateOnline(String mobilenumber) {
		
		return userDao.updateOnline(mobilenumber);
	}
	
	@Override
	public String statusOffline(String username) {
		
		return userDao.statusOffline(username);
	}
}
