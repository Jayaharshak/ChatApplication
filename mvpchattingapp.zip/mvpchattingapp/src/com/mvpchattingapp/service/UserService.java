package com.mvpchattingapp.service;

import java.util.List;

import javax.mail.Message;

import com.mvpchattingapp.model.User;
import com.mvpchattingapp.model.chatLog;

public interface UserService {
	
	public User findUserByMobilenumber(String mobilenumber, String password);
	public String addUser(User user);
	
	public List<User> getContactList();
	
	public String saveChatLog(chatLog newlog);
	
	public List<chatLog> getChatLogByUsername(String fromuser,String touser);
	
	public String updateOnline(String mobilenumber);
	public String statusOffline(String username);
	
}
